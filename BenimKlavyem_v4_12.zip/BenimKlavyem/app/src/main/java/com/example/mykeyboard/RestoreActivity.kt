package com.example.mykeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Yedekten geri yükleme: BackupActivity'nin kullandığı Drive klasöründeki EN SON "MYKEYBOARDYEDEK_*.json" (eski: "klavyeyedegim_*.json") dosyasını bulur,
 * önce "şu tarih-saatteki yedeğiniz yüklenecektir" diye (dosya boyutuyla) sorar, onaylanırsa pano + ayarları geri yükler.
 */
class RestoreActivity : Activity() {

    companion object {
        fun fmtSize(b: Long): String = when {
            b <= 0 -> "bilinmiyor"
            b < 1024 -> "$b B"
            b < 1024 * 1024 -> String.format(Locale("tr"), "%.1f KB", b / 1024.0)
            else -> String.format(Locale("tr"), "%.2f MB", b / 1048576.0)
        }
    }

    private class Found(val doc: Uri, val name: String, val whenMs: Long, val bytes: ByteArray)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (b != null) return
        val saved = getSharedPreferences("backup", Context.MODE_PRIVATE).getString("tree", null)
        if (saved == null) {
            Toast.makeText(this, "Önce bir yedek alıp Drive klasörünü seçmelisin", Toast.LENGTH_LONG).show()
            finish(); return
        }
        Toast.makeText(this, "Drive'daki en son yedek aranıyor…", Toast.LENGTH_SHORT).show()
        val tree = Uri.parse(saved)
        Thread {
            var found: Found? = null
            var err: String? = null
            try { found = findLatest(tree) } catch (e: Exception) { err = e.message ?: e.javaClass.simpleName }
            runOnUiThread { if (!isFinishing) { if (found != null) confirm(found) else fail(err ?: "Bu klasörde yedek dosyası bulunamadı") } }
        }.start()
    }

    // Yeni ad: MYKEYBOARDYEDEK_2026-10-31_21-31-05_10.5KB.json  |  eski ad: klavyeyedegim_2026-10-31_21-31-05.json
    private fun isBackupName(n: String) =
        n.endsWith(".json") && (n.startsWith(BackupActivity.PREFIX) || n.startsWith(BackupActivity.OLD_PREFIX))

    private fun parseStamp(name: String): Long? = try {
        val body = name.removePrefix(BackupActivity.PREFIX).removePrefix(BackupActivity.OLD_PREFIX)
        val stamp = body.take(BackupActivity.STAMP.length)
        SimpleDateFormat(BackupActivity.STAMP, Locale.US).parse(stamp)?.time
    } catch (_: Exception) { null }

    private fun findLatest(tree: Uri): Found? {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        var bestId: String? = null; var bestName = ""; var bestWhen = -1L
        contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: continue
                if (!isBackupName(name)) continue
                val t = parseStamp(name) ?: (if (c.isNull(2)) 0L else c.getLong(2))
                if (t > bestWhen) { bestWhen = t; bestId = c.getString(0); bestName = name }
            }
        }
        val id = bestId ?: return null
        val doc = DocumentsContract.buildDocumentUriUsingTree(tree, id)
        val bytes = contentResolver.openInputStream(doc)?.use { it.readBytes() } ?: throw IllegalStateException("Dosya okunamadı")
        return Found(doc, bestName, bestWhen, bytes)
    }

    private fun confirm(f: Found) {
        val stamp = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale("tr")).format(Date(f.whenMs))
        val msg = "Şu tarih ve saatteki yedeğiniz yüklenecektir:\n\n$stamp\n\n" +
            "Mevcut pano ve ayarlarınızın yerine geçecektir.\n\nDosya boyutu: ${fmtSize(f.bytes.size.toLong())}"
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Yedekten geri yükle")
            .setMessage(msg)
            .setPositiveButton("Yükle") { _, _ -> apply(f) }
            .setNegativeButton("İptal") { d, _ -> d.dismiss() }
            .setOnCancelListener { finish() }
            .setOnDismissListener { if (!applying) finish() }
            .show()
    }

    private var applying = false

    private fun putAll(name: String, o: JSONObject) {
        val e = getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
        val ks = o.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            val v0 = o.get(k)
            if (k == "shotsAfter" && v0 is Number) { e.putLong(k, v0.toLong()); continue }   // Long olmalı; Int yazılırsa okurken çöker
            when (val v = v0) {
                is Boolean -> e.putBoolean(k, v)
                is Int -> e.putInt(k, v)
                is Long -> e.putLong(k, v)
                is Double -> e.putFloat(k, v.toFloat())
                is String -> e.putString(k, v)
                is JSONArray -> e.putStringSet(k, MutableList(v.length()) { v.getString(it) }.toSet())
                else -> {}
            }
        }
        e.commit()
    }

    private fun apply(f: Found) {
        applying = true
        try {
            val root = JSONObject(String(f.bytes, Charsets.UTF_8))
            if (root.optString("app") != "MyKeyboard") throw IllegalStateException("Bu dosya MyKeyboard yedeği değil")
            val clips = root.optJSONObject("clips"); val ui = root.optJSONObject("ui")
            if (clips == null && ui == null) throw IllegalStateException("Yedek dosyası boş")
            if (clips != null) putAll("clips", clips)
            if (ui != null) putAll("ui", ui)
            ImeService.instance?.reloadAfterRestore()
            AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Geri yüklendi ✓")
                .setMessage("Yedek yüklendi.\n\nDosya: ${f.name}\nDosya boyutu: ${fmtSize(f.bytes.size.toLong())}")
                .setPositiveButton("Tamam") { d, _ -> d.dismiss() }
                .setOnDismissListener { finish() }
                .show()
        } catch (e: Exception) {
            applying = false
            fail(e.message ?: e.javaClass.simpleName)
        }
    }

    private fun fail(m: String) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Geri yüklenemedi")
            .setMessage(m)
            .setPositiveButton("Tamam") { d, _ -> d.dismiss() }
            .setOnDismissListener { finish() }
            .show()
    }
}
