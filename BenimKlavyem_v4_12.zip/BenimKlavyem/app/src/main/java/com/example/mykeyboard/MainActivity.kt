package com.example.mykeyboard

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (40 * d).toInt(), (20 * d).toInt(), 20)
        }
        col.addView(TextView(this).apply {
            text = "BenimKlavyem kurulum\n\n1) Klavyeyi etkinleştir\n2) Klavyeyi seç\n3) Ekran görüntüsü iznini ver (önizleme için)"
            textSize = 16f
        })
        fun btn(t: String, a: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        btn("1) Klavyeyi etkinleştir") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        btn("2) Klavyeyi seç") { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        btn("3) Ekran görüntüsü izni") {
            val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
                    else Manifest.permission.READ_EXTERNAL_STORAGE
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(p), 1)
        }
        col.addView(EditText(this).apply { hint = "Buraya yazarak dene" })
        setContentView(col)
    }
}
