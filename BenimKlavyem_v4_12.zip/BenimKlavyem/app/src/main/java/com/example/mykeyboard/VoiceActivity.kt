package com.example.mykeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.widget.Toast

/** Klavyedeki mikrofon tuşu için saydam aktivite: sesle yazma (Google konuşma tanıma) açar. */
class VoiceActivity : Activity() {
    private var focus: AudioFocusRequest? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (b != null) return
        try {
            grabAudioFocus()   // müzik/video/bildirim sesleri mikrofona karışmasın
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)   // sunucu modeli: gürültüde daha dayanıklı
                // Kısa duraklamalarda (nefes, düşünme) kesme: sessizlik süresi 2 kat uzatıldı (3,6 sn / 3 sn)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3600L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
            }
            startActivityForResult(i, 2)
        } catch (_: Exception) {
            releaseAudioFocus()
            Toast.makeText(this, "Sesle yazma (Google) bulunamadı", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun grabAudioFocus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setOnAudioFocusChangeListener { }
                .build()
            am.requestAudioFocus(req)
            focus = req
        } catch (_: Exception) {}
    }

    private fun releaseAudioFocus() {
        try {
            val f = focus ?: return
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(f)
            focus = null
        } catch (_: Exception) {}
    }

    override fun onDestroy() { releaseAudioFocus(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val list = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        val conf = data?.getFloatArrayExtra(RecognizerIntent.EXTRA_CONFIDENCE_SCORES)
        // En yüksek güven skorlu adayı seç (skor yoksa ilk aday)
        var best = 0
        if (list != null && conf != null && conf.size == list.size) {
            for (k in conf.indices) if (conf[k] > conf[best]) best = k
        }
        val text = list?.getOrNull(best)
        if (resultCode == RESULT_OK && !text.isNullOrBlank()) {
            ImeService.pendingText = text
            ImeService.pendingAt = SystemClock.elapsedRealtime()
        }
        releaseAudioFocus()
        finish()
    }
}
