package com.example.mykeyboard

import android.content.Context
import android.util.AttributeSet
import android.widget.ScrollView

/** Ayar paneli: yüksekliği sınırlı, taşarsa kaydırılır. Pencere ekrandan uzun olup klavyenin kapanmasını önler. */
class CapScrollView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : ScrollView(ctx, attrs) {
    @JvmField var maxPx = 0
    override fun onMeasure(w: Int, h: Int) {
        val hs = if (maxPx > 0) MeasureSpec.makeMeasureSpec(maxPx, MeasureSpec.AT_MOST) else h
        super.onMeasure(w, hs)
    }
}
