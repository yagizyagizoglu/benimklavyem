package com.example.mykeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Klavye yedeği: Google Drive'daki seçilen klasöre "MYKEYBOARDYEDEK_TARİH_SAAT_BOYUT.json" yazar
 * (örnek: MYKEYBOARDYEDEK_2026-10-31_21-31-05_10.5KB.json).
 * İlk seferde klasör seçtirir (sistem klasör seçicisi; hesap değiştirmek için seçicinin sol üstündeki menüyü kullan).
 * Sonraki basışlarda doğrudan yedekler ve hangi hesap/klasöre yazıldığını gösterip değiştirme seçeneği sunar.
 */
class BackupActivity : Activity() {
    private val REQ_PICK = 11
    private var pickOnly = false

    companion object {
        const val EXTRA_PICK_ONLY = "pickOnly"
        const val PREFIX = "MYKEYBOARDYEDEK_"
        const val OLD_PREFIX = "klavyeyedegim_"
        const val STAMP = "yyyy-MM-dd_HH-mm-ss"

        // Dosya adındaki boyut: 10.5KB / 850B / 1.25MB
        fun nameSize(b: Long): String = when {
            b < 1024 -> "${b}B"
            b < 1024 * 1024 -> String.format(Locale.US, "%.1fKB", b / 1024.0)
            else -> String.format(Locale.US, "%.2fMB", b / 1048576.0)
        }

        // Ayarlar > Google Drive bölümündeki "bağlı hesap / klasör" yazısı (ağ erişimi yok, kayıtlı bilgiyi okur)
        fun describe(c: Context): String {
            val p = c.getSharedPreferences("backup", Context.MODE_PRIVATE)
            if (p.getString("tree", null) == null)
                return "Henüz Drive klasörü seçilmedi. \"Yedekle\" ya da \"Klasör / hesap\" ile seç."
            val last = p.getString("lastBackup", null)
            return "Hesap: " + p.getString("treeAcc", "Google Drive") + "\nKlasör: " + p.getString("treeName", "(bilinmiyor)") +
                (if (last != null) "\nSon yedek: $last" else "")
        }
    }

    private fun prefs() = getSharedPreferences("backup", Context.MODE_PRIVATE)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (b != null) return
        pickOnly = intent?.getBooleanExtra(EXTRA_PICK_ONLY, false) == true
        val saved = prefs().getString("tree", null)
        if (pickOnly || saved == null) pickFolder() else runBackup(Uri.parse(saved), changed = false)
    }

    private fun pickFolder() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
            )
            Toast.makeText(this, "Google Drive'da yedek klasörünü seç", Toast.LENGTH_LONG).show()
            startActivityForResult(i, REQ_PICK)
        } catch (_: Exception) {
            Toast.makeText(this, "Klasör seçici açılamadı", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || uri == null) { finish(); return }
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {}
        prefs().edit().putString("tree", uri.toString())
            .putString("treeAcc", accountLabel(uri)).putString("treeName", folderName(uri)).apply()
        if (pickOnly) { showPicked(uri); return }
        runBackup(uri, changed = true)
    }

    private fun dumpPrefs(name: String): JSONObject {
        val o = JSONObject()
        for ((k, v) in getSharedPreferences(name, Context.MODE_PRIVATE).all) {
            when (v) {
                is Set<*> -> o.put(k, JSONArray(v.map { it.toString() }))
                null -> {}
                else -> o.put(k, v)
            }
        }
        return o
    }

    private fun runBackup(tree: Uri, changed: Boolean) {
        Toast.makeText(this, "Yedekleniyor…", Toast.LENGTH_SHORT).show()
        Thread {
            var fileName = ""
            var err: String? = null
            var size = -1L
            try {
                val now = Date()
                val root = JSONObject()
                root.put("app", "MyKeyboard")
                root.put("savedAt", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
                root.put("clips", dumpPrefs("clips"))
                root.put("ui", dumpPrefs("ui"))
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                val bytes = root.toString(2).toByteArray(Charsets.UTF_8)
                // Ad: MYKEYBOARDYEDEK_TARİH_SAAT_BOYUT.json
                fileName = PREFIX + SimpleDateFormat(STAMP, Locale.US).format(now) + "_" + nameSize(bytes.size.toLong()) + ".json"
                val doc = DocumentsContract.createDocument(contentResolver, parent, "application/json", fileName)
                    ?: throw IllegalStateException("Dosya oluşturulamadı")
                contentResolver.openOutputStream(doc, "wt")?.use { it.write(bytes) }
                    ?: throw IllegalStateException("Dosya yazılamadı")
                size = driveSize(doc, bytes.size.toLong())
                prefs().edit().putString("lastBackup", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr")).format(now))
                    .putString("treeAcc", accountLabel(tree)).putString("treeName", folderName(tree)).apply()
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
            }
            runOnUiThread { if (!isFinishing) showResult(tree, fileName, err, changed, size) }
        }.start()
    }

    private fun folderName(tree: Uri): String = try {
        val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        contentResolver.query(doc, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: "(bilinmiyor)"
    } catch (_: Exception) { "(bilinmiyor)" }

    // Android, klasör seçiciden hesabın e-postasını vermez; sağlayıcıyı ve (varsa) Drive hesap sırasını gösteriyoruz.
    private fun accountLabel(tree: Uri): String {
        val auth = tree.authority ?: ""
        if (!auth.contains("docs.storage")) return "Google Drive DEĞİL ($auth)"
        val acc = Regex("acc=(\\d+)").find(Uri.decode(tree.toString()))?.groupValues?.get(1)
        return if (acc != null) "Google Drive (cihazdaki ${acc}. hesap)" else "Google Drive"
    }

    private fun showPicked(tree: Uri) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Drive klasörü ayarlandı ✓")
            .setMessage("Hesap: " + accountLabel(tree) + "\nKlasör: " + folderName(tree) +
                "\n\nYedekler bu klasöre MYKEYBOARDYEDEK_TARİH_SAAT_BOYUT.json adıyla yazılır.")
            .setPositiveButton("Tamam") { d, _ -> d.dismiss() }
            .setOnDismissListener { finish() }
            .show()
    }

    private fun showResult(tree: Uri, fileName: String, err: String?, changed: Boolean, size: Long) {
        val msg = StringBuilder()
        if (err == null) {
            msg.append(if (changed) "Klasör ayarlandı ve yedek alındı.\n\n" else "Yedek alındı.\n\n")
            msg.append("Hesap: ").append(accountLabel(tree)).append("\n")
            msg.append("Klasör: ").append(folderName(tree)).append("\n")
            msg.append("Dosya: ").append(fileName).append("\n\n")
            msg.append("Başka hesap/klasör istiyorsan \"Klasörü değiştir\"e bas; seçicide sol üstteki menüden hesabı değiştirebilirsin.")
            msg.append("\n\nDosya boyutu: ").append(RestoreActivity.fmtSize(size))
        } else {
            msg.append("Yedek alınamadı:\n").append(err).append("\n\nKlasör: ").append(folderName(tree))
            msg.append("\n\nKlasörü yeniden seçmeyi dene.")
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(if (err == null) "Yedeklendi ✓" else "Hata")
            .setMessage(msg.toString())
            .setPositiveButton("Tamam") { d, _ -> d.dismiss() }
            .setNegativeButton("Klasörü değiştir") { _, _ -> skipFinish = true; pickFolder() }
            .setOnDismissListener { if (!skipFinish) finish() }
            .show()
    }

    // Drive'a yazılan dosyanın boyutunu sağlayıcıdan okur; okunamazsa yazılan bayt sayısı kullanılır
    private fun driveSize(doc: Uri, fallback: Long): Long = try {
        contentResolver.query(doc, arrayOf(DocumentsContract.Document.COLUMN_SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) it.getLong(0).takeIf { n -> n > 0 } else null
        } ?: fallback
    } catch (_: Exception) { fallback }

    private var skipFinish = false
}
