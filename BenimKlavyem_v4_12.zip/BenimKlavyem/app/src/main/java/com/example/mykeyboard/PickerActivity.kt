package com.example.mykeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock

/** Ataç menüsü için saydam seçici. EXTRA_KIND: 0 fotoğraf, 1 video, 2 belge. */
class PickerActivity : Activity() {
    companion object { const val EXTRA_KIND = "kind" }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (b != null) return   // döndürme vb. sonrası seçici zaten açık
        try {
            val kind = intent.getIntExtra(EXTRA_KIND, 2)
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)   // v4.1: istediğin kadar dosya seç
                when (kind) {
                    0 -> type = "image/*"
                    1 -> type = "video/*"
                    else -> type = "*/*"   // her tür belge/dosya seçilebilsin (kısıtlama yok)
                }
            }
            startActivityForResult(i, 1)
        } catch (_: Exception) {
            android.widget.Toast.makeText(this, "Dosya seçici açılamadı", android.widget.Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uris = ArrayList<android.net.Uri>()
        data?.clipData?.let { c -> for (k in 0 until c.itemCount) c.getItemAt(k).uri?.let { uris.add(it) } }
        if (uris.isEmpty()) data?.data?.let { uris.add(it) }
        if (resultCode == RESULT_OK && uris.isNotEmpty()) {
            val list = uris.map { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val mime = try { contentResolver.getType(uri) } catch (_: Exception) { null } ?: "application/octet-stream"
                Pair(uri, mime)
            }
            ImeService.pendingExtra = list.drop(1)
            ImeService.pending = list.first()
            ImeService.pendingAt = SystemClock.elapsedRealtime()
        }
        finish()
    }
}
