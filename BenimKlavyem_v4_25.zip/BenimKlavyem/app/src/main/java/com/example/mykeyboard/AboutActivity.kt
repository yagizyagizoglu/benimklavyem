package com.example.mykeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Hakkında: yapımcı bilgisi ve telif hakları metni. */
class AboutActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "" }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((22 * d).toInt(), (48 * d).toInt(), (22 * d).toInt(), (32 * d).toInt())
        }
        fun title(t: String) = col.addView(TextView(this).apply {
            text = t; textSize = 20f; setTypeface(typeface, Typeface.BOLD)
            setPadding(0, (18 * d).toInt(), 0, (6 * d).toInt())
        })
        fun body(t: String) = col.addView(TextView(this).apply { text = t; textSize = 15f; setLineSpacing(0f, 1.15f) })

        col.addView(TextView(this).apply {
            text = "BenimKlavyem"; textSize = 28f; setTypeface(typeface, Typeface.BOLD)
        })
        body("Sürüm $ver")

        // "Yapımcı hakkında" bölümünün üstünde, sağda küçük yuvarlak yapımcı fotoğrafı
        col.addView(LinearLayout(this).apply {
            gravity = Gravity.END
            addView(ImageView(this@AboutActivity).apply {
                setImageResource(R.drawable.yapimci)
                scaleType = ImageView.ScaleType.CENTER_CROP
                outlineProvider = ViewOutlineProvider.BACKGROUND
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFDDDDDD.toInt()); setStroke((2 * d).toInt(), 0xFFBBBBBB.toInt()) }
                clipToOutline = true
                contentDescription = "Yapımcı"
            }, LinearLayout.LayoutParams((64 * d).toInt(), (64 * d).toInt()).apply { topMargin = (10 * d).toInt() })
        })

        title("Yapımcı hakkında")
        body("Yapımcı: Yağız Yağızoğlu\n\nBu uygulamanın baştan aşağıya tüm kodlaması ve programlaması Yağız Yağızoğlu'na aittir.")

        // ---- Yapımcı sosyal medya ----
        title("Yapımcı sosyal medya")
        fun social(icon: Int, name: String, line2: String, url: String) {
            col.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
                addView(ImageView(this@AboutActivity).apply { setImageResource(icon) }, LinearLayout.LayoutParams((38 * d).toInt(), (38 * d).toInt()))
                addView(LinearLayout(this@AboutActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(this@AboutActivity).apply { text = name; textSize = 15f; setTypeface(typeface, Typeface.BOLD) })
                    addView(TextView(this@AboutActivity).apply { text = line2; textSize = 13f; setTextColor(0xFF1A73E8.toInt()) })
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = (12 * d).toInt() })
                setOnClickListener { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { Toast.makeText(this@AboutActivity, "Açılamadı", Toast.LENGTH_SHORT).show() } }
            })
        }
        social(R.drawable.ic_wa, "WhatsApp", "0553 165 98 93", "https://wa.me/905531659893")
        social(R.drawable.ic_ig, "Instagram", "instagram.com/yagizyagizogluu\nKullanıcı: yagizyagizogluu", "https://www.instagram.com/yagizyagizogluu")
        social(R.drawable.ic_fb, "Facebook", "facebook.com/yagizyagizogluu\nKullanıcı: yagizyagizogluu", "https://www.facebook.com/yagizyagizogluu")
        social(R.drawable.ic_yt, "YouTube", "Duygu Yağızoğlu", "https://www.youtube.com/results?search_query=Duygu+Ya%C4%9F%C4%B1zo%C4%9Flu")

        // ---- Geri bildirim: hata bildirimi / istek-görüş + 5 yıldız ----
        title("Geri bildirim")
        val prefs = getSharedPreferences("about", MODE_PRIVATE)
        var rating = prefs.getInt("rating", 0)
        var kind = 0   // 0 = Hata bildirimi, 1 = İstek / Görüş
        val stars = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val starViews = ArrayList<TextView>()
        fun paintStars() { starViews.forEachIndexed { i, t -> t.text = if (i < rating) "★" else "☆"; t.setTextColor(if (i < rating) 0xFFF5A623.toInt() else 0xFF888888.toInt()) } }
        for (i in 1..5) {
            val t = TextView(this).apply {
                textSize = 32f; gravity = Gravity.CENTER; setPadding((4 * d).toInt(), 0, (4 * d).toInt(), 0)
                setOnClickListener {
                    rating = if (rating == i) 0 else i
                    prefs.edit().putInt("rating", rating).apply(); paintStars()
                    if (rating > 0) Toast.makeText(this@AboutActivity, "Puanın: $rating/5 — teşekkürler!", Toast.LENGTH_SHORT).show()
                }
            }
            starViews.add(t); stars.addView(t)
        }
        paintStars()
        body("Uygulamayı beğendin mi? Puan ver:")
        col.addView(stars)

        fun chip(label: String) = TextView(this).apply {
            text = label; textSize = 14f; gravity = Gravity.CENTER
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
        }
        val chipBug = chip("🐞 Hata bildirimi"); val chipReq = chip("💡 İstek / Görüş")
        fun paintChips() {
            for ((i, c) in listOf(chipBug, chipReq).withIndex()) {
                val on = i == kind
                c.background = GradientDrawable().apply { cornerRadius = 20 * d; setColor(if (on) 0xFF1A73E8.toInt() else 0xFFEEEEEE.toInt()) }
                c.setTextColor(if (on) 0xFFFFFFFF.toInt() else 0xFF333333.toInt())
            }
        }
        chipBug.setOnClickListener { kind = 0; paintChips() }
        chipReq.setOnClickListener { kind = 1; paintChips() }
        paintChips()
        col.addView(LinearLayout(this).apply {
            setPadding(0, (12 * d).toInt(), 0, (8 * d).toInt())
            addView(chipBug); addView(chipReq, LinearLayout.LayoutParams(-2, -2).apply { marginStart = (8 * d).toInt() })
        })
        val msg = EditText(this).apply {
            hint = "Hatayı, isteğini ya da görüşünü yaz…"; minLines = 4; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        col.addView(msg, LinearLayout.LayoutParams(-1, -2))
        col.addView(TextView(this).apply {
            text = "Gönder"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt()); setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply { cornerRadius = 12 * d; setColor(0xFF1A73E8.toInt()) }
            setOnClickListener {
                val text = msg.text.toString().trim()
                if (text.isEmpty() && rating == 0) { Toast.makeText(this@AboutActivity, "Bir mesaj yaz ya da yıldız ver", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                val konu = if (kind == 0) "Hata bildirimi" else "İstek / Görüş"
                val govde = "$text\n\n— — —\nPuan: ${if (rating > 0) "$rating/5" else "verilmedi"}\nSürüm: $ver\nCihaz: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})"
                // Doğrudan sunucu yok: kullanıcının e-posta uygulaması hazır dolu açılır, "Gönder"e basması yeterli
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
                    putExtra(Intent.EXTRA_EMAIL, arrayOf("dyagizoglu@gmail.com"))
                    putExtra(Intent.EXTRA_SUBJECT, "BenimKlavyem $ver — $konu")
                    putExtra(Intent.EXTRA_TEXT, govde)
                }
                try { startActivity(i) } catch (_: Exception) { Toast.makeText(this@AboutActivity, "E-posta uygulaması bulunamadı", Toast.LENGTH_LONG).show() }
            }
        }, LinearLayout.LayoutParams(-1, (46 * d).toInt()).apply { topMargin = (10 * d).toInt() })

        title("Telif hakları ve kanuni haklar")
        body(
            "© 2026 Yağız Yağızoğlu. Tüm hakları saklıdır.\n\n" +
            "BenimKlavyem; kaynak kodu, tasarımı, ekran düzeni, simgesi ve adıyla birlikte bir yazılım eseridir. " +
            "5846 sayılı Fikir ve Sanat Eserleri Kanunu'na göre bilgisayar programları da eser sayılır ve eser sahibi, eseri meydana getirdiği anda koruma kazanır; ayrıca bir tescil yaptırması gerekmez.\n\n" +
            "Eser sahibine kanun iki tür hak tanır. Manevi haklar: eserin kime ait olduğunun belirtilmesi, eserde izinsiz değişiklik yapılmasının engellenmesi ve eserin ilk kez ne zaman yayımlanacağına karar verme. " +
            "Mali haklar: eserin çoğaltılması, yayılması, işlenmesi, satılması ya da kiraya verilmesi gibi kullanımlar üzerinde tek yetkili olma.\n\n" +
            "Bu nedenle yapımcının önceden yazılı izni olmadan bu uygulamanın veya herhangi bir parçasının:\n" +
            "• çoğaltılması, kopyalanması,\n" +
            "• satılması, kiralanması, ücret karşılığı veya ücretsiz dağıtılması,\n" +
            "• değiştirilerek, adı ya da simgesi değiştirilerek yeniden yayımlanması,\n" +
            "• kaynak kodunun alınıp başka bir üründe kullanılması\n" +
            "yasaktır. İzinsiz kullanım hâlinde eser sahibinin kanundan doğan hukuki ve cezai yollara başvurma hakkı saklıdır.\n\n" +
            "Uygulama kişisel kullanım için sunulmuştur. Kullanım hakkı, eserin mülkiyetinin ya da telif haklarının devri anlamına gelmez."
        )

        title("Üçüncü taraf hizmetler")
        body("Sesle yazma, Google çeviri ve Google Drive yedekleme gibi özellikler ilgili şirketlerin hizmetlerinden yararlanır; bu hizmetlerin hakları sahiplerine aittir.")

        body("\nBu metin bilgilendirme amaçlıdır, hukuki danışmanlık yerine geçmez.")
        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(-1, -2))
        })
    }
}
