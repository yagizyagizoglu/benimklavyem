# BenimKlavyem
- Üst sol yuvarlak buton: Google Çeviri (alandaki yazıyı çeviriye gönderir)
- Üstte: en başta SON KOPYALANAN METNİN önizlemesi (dokununca yapıştırır) + son 3 ekran görüntüsü
- Sağ üst pano: ☆ ile sabitle, "Sabitler" sekmesi, basılı tutup sürükleyerek sırala
- ?123 -> semboller, =\< -> 2. sembol sayfası, 1234 -> sayı tuşları

## APK nasıl alınır
A) Android Studio: klasörü aç -> Build > Build APK.
B) Sadece telefonla: GitHub'a yeni repo aç, dosyaları yükle -> Actions > "Build APK" -> Artifacts'tan APK indir.
Kurduktan sonra uygulamayı aç: 1) etkinleştir 2) seç 3) ekran görüntüsü izni.

## v1.5
- Sol üst: ▦ = Google Çeviri (Türkçe⇄İngilizce), yanında pano
- Sağ üst: boyut (yükseklik, genişlik %60-100, sol/orta/sağ hizalama, titreşim)
- Pano: öğeye basılı tut = sabitle/çöz, ≡ tutamacıyla sürükle = sırala
- Çift dokunuş ⇧ = Caps Lock, silme tuşu hızlanarak tekrar eder

## v4.24
- Öğrenen dokunuş: klavye parmağının tuşlara nasıl bastığını (ekranın sol/orta/sağ bölgesi için ayrı) cihazda öğrenir; tuşun kenarına düşen basışı öğrenilen kaymaya göre asıl hedeflenen komşu harfe düzeltir. Yazdığın metin kaydedilmez, yalnızca birkaç sayı saklanır. Ayarlar > "Öğrenme" düğmesi: dokun = aç/kapat, basılı tut = öğrenilenleri sıfırla
- Menü tuşunu 5 sn basılı tutunca mail listesi (2,5 sn'lik Ayarlar kısayolu araya girmesin diye düzeltildi)
- Hakkında'dan dönünce önceki ekran (Ayarlar vb.) açılır
- Pano/Sabitle, Ayarlar, Çeviri ekranında sağa/sola kaydırınca ana şeride dönüş
- Üst şerit %10 yükseldi, son kopyalanan kutusuna çerçeve, aşağı alma tuşları küçüldü ve köşelere alındı

## v4.12
- Ana şeritteki ayar çarkı kaldırıldı (Menü ▦ ile açılan ikinci şeritte Pano/Çeviri/Tema'nın yanında durur); sağ uçta yalnızca "klavyeyi kapat" düğmesi kalır
- Ekran görüntüleri + son kopyalanan sağa kaydırıldı; menü ile ataç arası boşluk hafif artırıldı; mikrofon biraz sağa çekildi

## v4.11
- Pano paneli: "En son" + "Sabitlenenler" başlığı + ilk üç sabit not artık tam ekranda görünecek şekilde sığdırıldı (başlıklar, geçmiş satırı ve not kâğıdı alçaltıldı)
- Pano başlığı: soldaki klavye düğmesi ile Sil tuşu arasındaki ipucu yazısı ortada kutucuk içinde

## v4.10
- Mikrofon ataca, son kopyalanan kutusu mikrofona (ve sağda ekran görüntüsüne) bitişik; ekran görüntüleri sağdaki 👇 düğmesine, o da çarka bitişik

## v4.9
- Araç şeridi (Pano, Çeviri, Tema): üç düğme birbirine bitişik, sağa kaydırıldı; sağdaki 👇 (klavyeyi aşağı al) düğmesinin hemen yanında

## v4.8
- Pano / Sabitlenenler ekranı başlığında, sağdaki klavye düğmesinin soluna Sil (⌫) tuşu: klavye düğmesiyle aynı renk ve boyutta, basılı tutunca tekrar eder

## v4.7
- Son kopyalanan kutusunda ↩ yerine sol üst köşede "Geri al" yazısı (bir önceki kopyalananı getirir; "İleri al" ile en yeniye dönülür)
- Soldaki ve sağdaki 👇 (klavyeyi aşağı al) düğmeleri %25 büyüdü

## v4.6
- Alt sıradaki 🌐 tuşu kaldırıldı (boşluk tuşu eski genişliğine döndü)
- Soldaki ve sağdaki 👇 (klavyeyi aşağı al) düğmeleri yaklaşık yarı boyuta küçüldü
- Menü tuşu soldaki 👇'ya, Ataç menüye, Mikrofon ataca iyice yaklaştı
- Son kopyalanan kutusu daha geniş

## v4.4
- ▶ (next) tuşu kaldırıldı
- Sağdaki 👇 ve ayarlar (çark) düğmeleri biraz küçüldü (genişlik ve yükseklik)
- Üst şeritte son İKİ ekran görüntüsü yan yana; son kopyalanan kutusu daha geniş
- Yeni bir şey kopyalanınca kutuda ↩ belirir: basınca bir önceki kopyalanan gelir, ↪ ile en yeniye dönülür

## v4.3
- Araç şeridindeki mavi 🌐 (klavye seçici) düğmesi kaldırıldı

## v4.2
- Üst şerit: Menü tuşu klavye (👇) tuşuna biraz yaklaştı; Ataç daha sola, Mikrofon menüye daha yakın
- ▶ (next) tuşu çarka (sağa) yaklaştı: aradaki 👇 düğmesi daraltıldı
- Son kopyalanan kutusu daha geniş

## v4.1
- Üst şerit: ▶ ile ayarlar (çark) arasına ikinci "klavyeyi aşağı al" (👇) düğmesi; araç şeridine 🌐 düğmesi (tek dokunuşta klavye seçici açılır)
- Pano: başlıkta sağdaki klavye düğmesinin aynısı solda da var
- Sabitlenenler: tek sırada 3 not; not kâğıdı yüksekliği yazı kadar (başlık hariç en çok ilk 4 satır görünür)
- Geçmiş: son 30 kayıt; 30'u geçen en eskiler geçmiş çöp kutusuna (geri dönüşüm) gider; çöp kutusu da 30'a kadar tutar, dolunca yeniler eskilerin yerine yazılır
- Sayı sayfası alt sıra: ABC · , · . · 0 · boşluk (0 ile sil arasında) · sil · OK; hepsi aynı yükseklikte
- Emoji: "En son"un yanında 📌 Sabitlenen kategorisi; emojiye basılı tut = Sabitlenen'e ekle; Sabitlenen içinde basılı tutup sürükle = yer değiştir, sürüklemeden bırak = kaldır sorusu
- Ataç: fotoğraf / video / belge seçicide birden fazla dosya seçilir; sırayla (aralıklı) gönderilir

## v3.9 (v70)
- Üst şeritte ayarlar simgesinin soluna koyu yeşil, sağa bakan ▶ (next) tuşu: basınca o anki alana "next" yazar ve OK tuşuyla aynı yolla gönderir

## v3.8 (v69)
- Ayarlar paneli ekranın ~%55'iyle sınırlandı ve kendi içinde kayar (pencere ekrandan uzun olunca klavye kapanıyordu); panel hatası klavyeyi kapatmaz
- Pano / çeviri / düzenle / ayarlar sayfasındayken üstteki menü şeridi gizlenir
- "Kaydırarak boyutlandır" alanı ince çubuk şeklinde
- Son kopyalanan kutusuna basılı tutunca menü: Kopyala · Seç · Sabitle
- Menü düğmesinin soluna "klavyeyi aşağı al" oku (⌄) eklendi
- Alt sıra: ?123, @, 😊 emoji, boşluk, Alt, nokta, OK (virgül ve @ yer değiştirdi: sembol sayfasında virgül, harf ekranında @; emoji araç şeridinden alt sıraya taşındı; Alt ile nokta yer değiştirdi)
- Son kopyalanan metin kutusunda yazı kutunun en üstünden başlar
- Ataç: belge seçici her türlü dosyayı gösterir; alan içerik kabul etmiyorsa (tarayıcı vb.) dosya panoya konur ve yapıştırma denenir
- Ayarlar: hazır yükseklik düzeyleri, kaydırarak boyutlandırma alanı (yukarı/aşağı = yükseklik, sağa/sola = genişlik), dikey/yatay ayrı yükseklik, tuş sesi, yükseklik en fazla ekranın ~%60'ı
- Kararlılık: bozuk/yedekten gelen ayar türleri güvenli okunur, arka plan işleri ve yazım denetimi hataları klavyeyi düşürmez, sıfırlama/geri yükleme ana iş parçacığını dondurmaz, yardımcı ekranlar döndürmede yeniden kurulmaz
- Alt sistem şeridi (ok + dünya simgesi) klavye rengine bağlanır, sistem gri perdesi kapatıldı

## v3.7 (v68)
- Titreşim düzeltildi: sistemin dokunma-geri-bildirim ayarına bağlı kalmadan doğrudan titreşim motoru kullanılır (VIBRATE izni eklendi). Titreşimi açınca bir kez titrer
- Ayarlar: Yükseklik / Genişlik / Hız / Tepkime süresi / Sol-Orta-Sağ el / Titreşim tek bir grupta toplandı; "Tümünü sıfırla" ile "Hakkında" arasındaki ayarlar simgesine basınca açılır-kapanır

## v3.6 (v67)
- Ayarlar > Google Drive: "Hesap/Klasör" düğmesi en başa alındı ve Drive simgesi kullanıyor (sonra Yedekle, Geri yükle)

## v3.5 (v66)
- Menü düğmesinin bulunduğu üst şerit 52dp -> 62dp yükseltildi (tuş yüksekliği ayarı değişmedi)

## v3.4 (v65)
- Kurulum ekranı güncellemeden sonra / her açılışta kendiliğinden gelmez (başlatıcı simgesi kaldırıldı)
- Ayarlar paneline "Kurulum ekranı" düğmesi eklendi: basınca etkinleştir / seç / ekran görüntüsü izni ekranı açılır (sistemin klavye ayarlarındaki dişliden de açılır)

## v3.3 (v64)
- Proje, uygulama ve APK adı: BenimKlavyem (BenimKlavyem.apk). Paket kimliği (com.example.mykeyboard) aynı kaldı: eski sürümün üstüne kurulur, ayarlar ve pano silinmez

## v3.2 (v63)
- Sembol / sayı ekranlarında tuşlar uzatıldı: klavyenin toplam yüksekliği harf ekranıyla aynı (ekran değişince klavye zıplamaz)
- Emoji tuşu alttaki sıradan çıktı; renkli emoji simgesi araç şeridinde açık/koyu tema simgesinin yanında
- Araç şeridi (Pano, Çeviri, Tema, Emoji) menü tuşuna yaklaştırıldı, aralar daraltıldı; Ayarlar simgesi aynı yerde
- Üst şeritte 3 yerine yalnızca EN SON ekran görüntüsü; "son kopyalanan" kutusu daha da genişledi
- Son kopyalanan kutusuna BASILI TUT: metin Sabitlenenler'e eklenir

## v3.1 (v62)
- Ayarlar: "Tepkime süresi" çubuğunun altına GOOGLE DRIVE bölümü eklendi: bağlı hesap / klasör bilgisi, Yedekle, Geri yükle ve Klasör-hesap değiştir düğmeleri (üst şeritteki Yedekle/Geri yükle simgeleri buraya taşındı, aynı simgelerle)
- Yedek dosya adı: MYKEYBOARDYEDEK_TARİH_SAAT_BOYUT.json (örn. MYKEYBOARDYEDEK_2026-10-31_21-31-05_10.5KB.json); geri yükleme eski "klavyeyedegim_*" yedeklerini de tanır
- Üst şerit: Ataç ve Mikrofon menüye yaklaştırıldı ve renklendirildi (ataç mavi, mikrofon kırmızı); "son kopyalanan metin" kutusu genişletildi

## v3.0 (v61)
- Üst şerit: son kopyalanan metin önizlemesi + son 3 ekran görüntüsü (eskiden 5)
- Yandaki tuşa sıçrama koruması: aynı parmağın taşan "hayalet" dokunuşu yok sayılır
- Silme tuşu: sabit ritimli tekrar (bazı uygulamalarda ani hızlanma düzeltildi)
- Yazım denetimi: yanlış Türkçe kelime kırmızı altı çizili; kelimeye dokununca öneri listesi çıkar
  (Android'in yazım denetimi gerekir: Ayarlar > Dil > Yazım denetimi açık + Türkçe)
