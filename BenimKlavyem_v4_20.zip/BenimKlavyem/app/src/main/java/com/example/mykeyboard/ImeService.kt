package com.example.mykeyboard

import android.Manifest
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.util.TypedValue
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.style.SuggestionSpan
import android.view.textservice.SentenceSuggestionsInfo
import android.view.textservice.SpellCheckerSession
import android.view.textservice.SuggestionsInfo
import android.view.textservice.TextInfo
import android.view.textservice.TextServicesManager
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.ContextThemeWrapper
import androidx.core.view.WindowCompat
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.util.Size
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONObject

/** Drawable'ı XML'den her seferinde şişirmek yerine ConstantState'ten kopyalar (tuş yaratma ve shift ikonu hızlanır). */
private object DrawCache {
    private val m = HashMap<Int, Drawable.ConstantState>()
    fun get(ctx: Context, res: Int): Drawable? {
        val cs = m[res]
        if (cs != null) return cs.newDrawable(ctx.resources, ctx.theme)
        val d = ctx.getDrawable(res) ?: return null
        d.constantState?.let { m[res] = it }
        return d
    }
    fun clear() = m.clear()
}

private class KeyView(ctx: Context) : TextView(ctx) {
    var icon: Drawable? = null
    var hf = 1f
    var fillN = 0       // > 0: satır sayısı harf ekranından az (sembol/sayı); tuşlar uzatılıp toplam yükseklik harf ekranıyla eşitlenir
    var fillS = 0f      // bu ekranın satır yükseklik çarpanları toplamı
    var tf = 1f
    var tag2 = -1f
    fun setIcon(res: Int, color: Int) {
        icon = DrawCache.get(context, res)?.mutate()?.also { it.setTint(color) }
        invalidate()
    }
    private val sz = (24 * resources.displayMetrics.density).toInt()
    var tiny = false   // true: "OK" yazısının altında çok küçük ikon
    private val tinySz = (10 * resources.displayMetrics.density).toInt()
    private val tinyBottom = (7.5f * resources.displayMetrics.density).toInt()
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        icon?.let { d ->
            if (tiny) {
                val l = (width - tinySz) / 2; val t = height - tinyBottom - tinySz
                d.setBounds(l, t, l + tinySz, t + tinySz); d.draw(c)
            } else {
                val l = (width - sz) / 2; val t = (height - sz) / 2
                d.setBounds(l, t, l + sz, t + sz); d.draw(c)
            }
        }
    }
}

/** Menü düğmesi: 2x2 kare, içlerinde tek tek m e n ü harfleri. */
private class MenuGridDrawable(private val px: Int, private val fg: Int) : Drawable() {
    private val letters = arrayOf("m", "e", "n", "ü")
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fg; alpha = 45 }
    private val neon = 0xFF39FF14.toInt()
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = neon; style = Paint.Style.STROKE; strokeWidth = px / 20f }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = neon; alpha = 80; style = Paint.Style.STROKE; strokeWidth = px / 9f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fg; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val r = RectF()
    private val tb = Rect()
    override fun getIntrinsicWidth() = px
    override fun getIntrinsicHeight() = px
    override fun draw(c: Canvas) {
        val b = bounds
        val gap = b.width() * 0.09f
        val cell = (b.width() - gap) / 2f
        txt.textSize = cell * 0.78f
        txt.getTextBounds("n", 0, 1, tb)
        val rad = cell * 0.22f
        for (i in 0..3) {
            val l = b.left + (i % 2) * (cell + gap)
            val t = b.top + (i / 2) * (cell + gap)
            r.set(l, t, l + cell, t + cell)
            c.drawRoundRect(r, rad, rad, fill)
            c.drawRoundRect(r, rad, rad, glow)
            c.drawRoundRect(r, rad, rad, stroke)
            c.drawText(letters[i], r.centerX(), r.centerY() + tb.height() / 2f, txt)
        }
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Ekran görüntüsü numarası: dairesiz, yalnız yeşil neon rakam; seçiliyken kırmızı. */
private class ShotBadge(ctx: Context, val num: Int) : View(ctx) {
    var on = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val cx = w / 2f; val cy = height / 2f
        val col = if (on) 0xFFFF1744.toInt() else 0xFF39FF14.toInt()
        p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = w * 0.52f
        val fm = p.fontMetrics
        val y = cy - (fm.ascent + fm.descent) / 2f
        p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.16f; p.color = col; p.alpha = 90   // neon parlama
        c.drawText(num.toString(), cx, y, p)
        p.style = Paint.Style.FILL; p.color = col
        c.drawText(num.toString(), cx, y, p)
    }
}

class ImeService : InputMethodService() {

    companion object {
        // Ataç ile seçilen dosya: seçici ekranı kapanıp klavye tekrar bağlanınca gönderilir
        @Volatile var pending: Pair<Uri, String>? = null
        // Sesle yazma sonucu (VoiceActivity) – aynı şekilde klavye bağlanınca yazılır
        @Volatile var pendingText: String? = null
        // v4.1: çoklu seçimde ilkinden sonraki dosyalar (sırayla gönderilir)
        @Volatile var pendingExtra: List<Pair<Uri, String>> = emptyList()
        @Volatile var pendingAt = 0L
        private const val PENDING_TTL_MS = 120_000L   // eski/bayat sonuç yanlış alana gitmesin
        @Volatile var instance: ImeService? = null     // geri yükleme sonrası klavyeyi yeniden okutmak için
    }

    private enum class Mode { LETTERS, SYM1, SYM2, NUM, EMOJI }
    private class K(
        val label: String, val w: Float = 1f, val repeat: Boolean = false,
        val letter: Boolean = false, val isShift: Boolean = false, val isEnter: Boolean = false,
        val kind: Int = 0,          // 0 harf, 1 işlev (dikdörtgen), 2 işlev (hap), 3 enter, 4 sil (hafif kırmızı), 5 Alt (hafif sarı)
        val icon: Int = 0, val small: Boolean = false, val hf: Float = 1f, val spacer: Boolean = false,
        val act: () -> Unit
    )
    private class Shot(val uri: Uri, val mime: String, val bmp: Bitmap?)

    private val tr = Locale("tr", "TR")
    private val handler = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private val net = Executors.newSingleThreadExecutor()
    private lateinit var store: ClipStore
    private lateinit var cm: ClipboardManager
    private lateinit var keys: LinearLayout
    private lateinit var thumbs: LinearLayout
    private lateinit var thumbsWrap: View
    private lateinit var attachCats: View
    private var deliverTries = 0
    private var thumbGen = 0
    private lateinit var kbRoot: View
    private lateinit var toolbar: View
    private lateinit var driveInfo: TextView
    private lateinit var btnTr: ImageButton
    private lateinit var btnCl: ImageButton
    private lateinit var wrapper: FrameLayout
    private lateinit var tctx: Context
    private lateinit var btnTheme: ImageButton
    private var dark = true
    private lateinit var widthLabel: TextView
    private lateinit var hapticBtn: TextView
    private lateinit var alignBtns: List<TextView>
    private lateinit var touchHelper: ItemTouchHelper
    private lateinit var clipPanel: View
    private lateinit var sizePanel: View
    private lateinit var topStrip: View
    private lateinit var translatePanel: View
    private lateinit var editPanel: View
    private lateinit var tEdit: TextView
    private lateinit var tTitle: TextView
    private lateinit var btnUndo: TextView
    private lateinit var clipHint: TextView
    private var clipView = 0   // 0 normal, 1 sabit çöp kutusu, 2 geçmiş çöp kutusu
    private lateinit var clipDlg: View
    private lateinit var dlgMsg: TextView
    private lateinit var dlgBtns: List<TextView>
    private var editOnTitle = false   // düzenlemede yazılan alan: başlık mı metin mi
    private var otherBuf = ""         // aktif olmayan alanın içeriği
    private var otherCur = 0
    private var editing = false
    private var editCur = 0
    private var editStart = 0
    private var editPre = 0
    private var editItem: ClipItem? = null
    private var enterChk = false
    private var appliedSig = ""
    private lateinit var sizeLabel: TextView
    private lateinit var tInput: TextView
    private lateinit var tOutput: TextView
    private lateinit var chipFrom: TextView
    private lateinit var chipTo: TextView
    private lateinit var adapter: ClipAdapter

    private var mode = Mode.LETTERS
    private var shift = false
    private var keyH = 38
    private var kbPct = 100
    private var kbAlign = 1
    private var haptic = false

    // Titreşim: sistemin "dokunma geri bildirimi" ayarına bağlı kalmasın diye doğrudan Vibrator kullanılır (VIBRATE izni var)
    private val vib: android.os.Vibrator? by lazy {
        try {
            if (Build.VERSION.SDK_INT >= 31)
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager).defaultVibrator
            else (getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator)
        } catch (_: Exception) { null }
    }
    private fun buzz(long: Boolean = false, fallbackView: View? = null) {
        try {
            val v = vib
            if (v != null && v.hasVibrator()) {
                val ms = if (long) 30L else 14L
                val amp = if (v.hasAmplitudeControl()) (if (long) 255 else 170) else android.os.VibrationEffect.DEFAULT_AMPLITUDE
                v.vibrate(android.os.VibrationEffect.createOneShot(ms, amp))
                return
            }
        } catch (_: Exception) {}
        try {   // Vibrator yoksa / olmadıysa klasik dokunma geri bildirimi (sistem ayarını yok sayarak)
            (fallbackView ?: wrapper).performHapticFeedback(
                if (long) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING)
        } catch (_: Exception) {}
    }
    private var repSpeed = 5      // 1..10 silme/tekrar hızı
    private val altDelayMs = 700   // ş ı ğ ö vb. menüsü ancak 0,7 sn parmak oynamadan basılı tutunca açılır; 0,4 sn basılı tutmada AÇILMAZ (Tepkime süresi ayarından bağımsız)
    private var holdMs = 300      // basılı tutunca tekrar/alternatif başlama süresi (ms)
    private var caps = false
    private var lastShiftTap = 0L
    private val modeViews = HashMap<Mode, LinearLayout>()
    private val keyViews = ArrayList<KeyView>()
    private val letterViews = ArrayList<TextView>()
    private val enterViews = ArrayList<KeyView>()
    private var shiftView: KeyView? = null

    // çeviri
    private var translating = false
    private var fromTr = true
    private val tbuf = StringBuilder()
    private var tOut = ""
    private var reqId = 0
    private val trRunnable: Runnable = Runnable { doTranslate() }

    private val thumbCache = HashMap<String, Bitmap>()
    @Volatile private var lastThumbKey = ""

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged() }

    private fun onClipChanged() {
        try {
            val clip = cm.primaryClip ?: return
            val desc = clip.description
            if (!(desc.hasMimeType("text/plain") || desc.hasMimeType("text/html"))) return
            // Şifre yöneticisi gibi "hassas" işaretli kopyaları geçmişe kaydetme
            if (desc.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
            if (clip.itemCount == 0) return
            val t = clip.getItemAt(0).coerceToText(this)?.toString()
            // Çok büyük metinler her kopyada diske yazılırken klavyeyi yavaşlatır
            if (t.isNullOrBlank() || t.length > 20000) return
            store.addHistory(t)
            if (::clipPanel.isInitialized && clipPanel.visibility == View.VISIBLE) reloadClips()
            // Üstteki şeritte "son kopyalanan metin" önizlemesini tazele
            handler.removeCallbacks(thumbRunnable); handler.postDelayed(thumbRunnable, 150)
        } catch (_: Exception) {}   // SecurityException vb. klavyeyi düşürmesin
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        store = ClipStore(this)
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
        loadPrefs()
    }

    // ---------- Güvenli ayar okuma: yedekten gelen / bozuk türde bir değer klavyeyi çökertmesin ----------
    private fun pInt(k: String, d: Int): Int = try { (prefs().all[k] as? Number)?.toInt() ?: d } catch (_: Exception) { d }
    private fun pLong(k: String, d: Long): Long = try { (prefs().all[k] as? Number)?.toLong() ?: d } catch (_: Exception) { d }
    private fun pBool(k: String, d: Boolean): Boolean = try { (prefs().all[k] as? Boolean) ?: d } catch (_: Exception) { d }

    private val KEY_MIN = 24
    private val KEY_MAX = 80
    private fun isLand() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private fun keyHKey() = if (isLand()) "keyH2L" else "keyH2"
    private fun loadKeyH() { keyH = pInt(keyHKey(), if (isLand()) 30 else 38).coerceIn(KEY_MIN, KEY_MAX) }

    private fun loadPrefs() {
        loadKeyH()
        dark = pBool("dark", true)
        kbPct = pInt("kbPct", 100).coerceIn(60, 100)
        kbAlign = pInt("kbAlign", 1).coerceIn(0, 2)
        haptic = pBool("haptic2", false)
        sound = pBool("sound", false)
    }

    // Klavye ekranın en fazla ~%60'ını kaplasın (yatay ekranda yazı alanı kapanmasın); kayıtlı değer değişmez
    private fun effH(): Int {
        val dm = resources.displayMetrics
        val hDp = dm.heightPixels / dm.density
        val maxH = ((hDp * 0.6f - 62f - 4f - 38f) / 5.05f).toInt()
        return keyH.coerceAtMost(maxOf(maxH, 22)).coerceAtLeast(22)
    }

    private fun safeExec(ex: java.util.concurrent.ExecutorService, f: () -> Unit) {
        try { ex.execute { try { f() } catch (_: Exception) {} } } catch (_: Exception) {}   // servis kapanırken RejectedExecutionException olmasın
    }

    private var sound = false
    private val audio: AudioManager? by lazy { try { getSystemService(Context.AUDIO_SERVICE) as AudioManager } catch (_: Exception) { null } }
    private fun click() { try { audio?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, -1f) } catch (_: Exception) {} }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        try { loadKeyH(); appliedSig = ""; navSig = ""; applyWidth(); applyNavBar() } catch (_: Exception) {}   // döndürme: yatay/dikey yükseklik ayrı
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        try { if (::cm.isInitialized) cm.removePrimaryClipChangedListener(clipListener) } catch (_: Exception) {}
        try { dismissAlts(); stopRepeat() } catch (_: Exception) {}
        closeSpell()
        handler.removeCallbacksAndMessages(null)
        try { bg.shutdownNow(); net.shutdownNow() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun attrColor(a: Int): Int {
        val tv = TypedValue(); tctx.theme.resolveAttribute(a, tv, true); return tv.data
    }

    private var navSig = ""
    // Alt şerit (aşağı ok + dünya simgesi) klavye rengiyle aynı olsun
    private fun applyNavBar() {
        if (!::tctx.isInitialized) return
        val w = window?.window ?: return
        val c = attrColor(R.attr.kbBg)
        val sig = "$c/$dark"
        if (sig == navSig) return   // aynı değeri tekrar tekrar pencereye yazıp yeniden düzen tetikleme
        navSig = sig
        try {
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            w.navigationBarColor = c
            if (Build.VERSION.SDK_INT >= 28) w.navigationBarDividerColor = c
            if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false   // alt şerit (ok + dünya simgesi) klavye renginde kalsın, sistem gri perde çekmesin
            WindowCompat.getInsetsController(w, w.decorView).isAppearanceLightNavigationBars = !dark
        } catch (_: Exception) {}
    }

    override fun onWindowShown() { super.onWindowShown(); applyNavBar() }
    private fun prefs() = getSharedPreferences("ui", Context.MODE_PRIVATE)

    // Yedekten geri yüklenen ayar ve panoyu klavyeye yeniden okut
    fun reloadAfterRestore() {
        handler.post {
            try {
                loadPrefs()
                setInputView(onCreateInputView())
                loadThumbs()
            } catch (_: Exception) {}
        }
    }

    // Ayarlar, pano kayıtları ve yedek klasörü dahil her şeyi ilk kurulum haline döndürür
    private fun resetAll() {
        // Sistem panosundaki (kopyalanmış ekran görüntüsü dahil) içerik de silinsin; önce bu, sonra kayıtlar
        try { if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip() else cm.setPrimaryClip(ClipData.newPlainText("", "")) } catch (_: Exception) {}
        for (n in listOf("ui", "clips", "backup")) getSharedPreferences(n, Context.MODE_PRIVATE).edit().clear().apply()   // apply: bellekte anında, diske arka planda
        safeExec(bg) { cacheDir.listFiles()?.forEach { it.deleteRecursively() } }                                      // dosya silme ana iş parçacığını dondurmasın
        pending = null; pendingText = null; pendingExtra = emptyList()
        repSpeed = 5; holdMs = 300
        clipView = 0
        // Ekran görüntüsü önizlemeleri: bu andan öncekiler klavyede bir daha gösterilmez
        getSharedPreferences("ui", Context.MODE_PRIVATE).edit().putLong("shotsAfter", System.currentTimeMillis() / 1000).apply()
        thumbCache.clear(); lastThumbKey = "reset"
        reloadAfterRestore()
        handler.post { reloadClips() }
    }

    override fun onCreateInputView(): View {
        // Görünüm yeniden kuruluyorsa (tema değişimi) eski menü/tekrar/zamanlayıcılar kalmasın
        loadKeyH()
        dismissAlts(); dismissMailPanel(); stopRepeat(); handler.removeCallbacks(holdRunnable)
        modeViews.clear(); keyViews.clear(); letterViews.clear(); enterViews.clear(); shiftView = null
        DrawCache.clear(); hlState.clear(); shownUpper = false; shownIcon = -1; navSig = ""
        handler.removeCallbacks(prebuildRunnable)
        translating = false; editing = false; enterChk = false; appliedSig = ""
        tctx = ContextThemeWrapper(this, if (dark) R.style.KbDark else R.style.KbLight)
        lastThumbKey = ""
        val root = LayoutInflater.from(tctx).inflate(R.layout.keyboard, null)
        kbRoot = root
        wrapper = object : FrameLayout(tctx) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                watchHold(ev)
                return super.dispatchTouchEvent(ev)
            }
        }.apply { setBackgroundColor(attrColor(R.attr.kbBg)) }
        wrapper.addView(root, FrameLayout.LayoutParams(-1, -2))
        keys = root.findViewById(R.id.keys)
        thumbs = root.findViewById(R.id.thumbs)
        thumbsWrap = root.findViewById(R.id.thumbsWrap)
        attachCats = root.findViewById(R.id.attachCats)
        root.findViewById<View>(R.id.btnAttach).setOnClickListener { showCats(attachCats.visibility != View.VISIBLE) }
        root.findViewById<View>(R.id.btnMic).setOnClickListener { showCats(false); openVoice() }
        root.findViewById<View>(R.id.catPhoto).setOnClickListener { openPicker(0) }
        root.findViewById<View>(R.id.catVideo).setOnClickListener { openPicker(1) }
        root.findViewById<View>(R.id.catDoc).setOnClickListener { openPicker(2) }
        root.findViewById<ImageButton>(R.id.btnMenu).setImageDrawable(MenuGridDrawable(dp(24), attrColor(R.attr.kbText)))
        toolbar = root.findViewById(R.id.toolbar)
        // Google Drive bölümü (Ayarlar > Tepkime süresinin altı): Yedekle / Geri yükle / Klasör-hesap
        driveInfo = root.findViewById(R.id.driveInfo)
        driveInfo.text = BackupActivity.describe(this)
        root.findViewById<View>(R.id.btnDriveBackup).setOnClickListener { launchTransparent(BackupActivity::class.java, -1, "Yedekleme açılamadı") }
        root.findViewById<View>(R.id.btnDriveRestore).setOnClickListener { launchTransparent(RestoreActivity::class.java, -1, "Geri yükleme açılamadı") }
        root.findViewById<View>(R.id.btnDriveFolder).setOnClickListener {
            try {
                startActivity(Intent(this, BackupActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    .putExtra(BackupActivity.EXTRA_PICK_ONLY, true))
            } catch (_: Exception) { Toast.makeText(this, "Klasör seçici açılamadı", Toast.LENGTH_SHORT).show() }
        }
        btnTr = root.findViewById(R.id.btnTranslate)
        btnCl = root.findViewById(R.id.btnClip)
        clipPanel = root.findViewById(R.id.clipPanel)
        sizePanel = root.findViewById(R.id.sizePanel)
        topStrip = root.findViewById(R.id.topStrip)
        translatePanel = root.findViewById(R.id.translatePanel)
        editPanel = root.findViewById(R.id.editPanel)
        tEdit = root.findViewById(R.id.tEdit)
        tTitle = root.findViewById(R.id.tTitle)
        tEdit.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                if (editOnTitle) switchEditField(false) else editTap(tEdit, e.x, e.y)
            }
            true
        }
        tTitle.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                if (!editOnTitle) switchEditField(true) else editTap(tTitle, e.x, e.y)
            }
            true
        }
        btnUndo = root.findViewById(R.id.btnUndo)
        clipHint = root.findViewById(R.id.clipHint)
        setupEmojiPanel(root)
        clipDlg = root.findViewById(R.id.clipDlg)
        dlgMsg = root.findViewById(R.id.dlgMsg)
        dlgBtns = listOf(root.findViewById(R.id.dlgB1), root.findViewById(R.id.dlgB2), root.findViewById(R.id.dlgB3))
        root.findViewById<View>(R.id.btnEBack).setOnClickListener { editItem = null; showPanel(1) }
        root.findViewById<View>(R.id.btnESave).setOnClickListener { saveEdit() }
        sizeLabel = root.findViewById(R.id.sizeLabel)
        widthLabel = root.findViewById(R.id.widthLabel)
        hapticBtn = root.findViewById(R.id.btnHaptic)
        tInput = root.findViewById(R.id.tInput)
        tOutput = root.findViewById(R.id.tOutput)
        chipFrom = root.findViewById(R.id.chipFrom)
        chipTo = root.findViewById(R.id.chipTo)

        btnTheme = root.findViewById(R.id.btnTheme)
        btnTheme.setImageResource(if (dark) R.drawable.ic_sun else R.drawable.ic_moon)
        btnTheme.setOnClickListener {
            dark = !dark
            prefs().edit().putBoolean("dark", dark).apply()
            handler.post { setInputView(onCreateInputView()); loadThumbs() }
        }
        root.findViewById<View>(R.id.btnHide).setOnClickListener { try { requestHideSelf(0) } catch (_: Exception) {} }
        root.findViewById<View>(R.id.btnHide2).setOnClickListener { try { requestHideSelf(0) } catch (_: Exception) {} }   // v4.1: ▶ ile ayarlar arasında ikinci "klavyeyi aşağı al"
        root.findViewById<View>(R.id.btnMenu).setOnClickListener {
            if (menuHeldFired) { menuHeldFired = false; return@setOnClickListener }   // 6 sn basılı tutma sonrası bırakınca menü açılıp kapanmasın
            setTools(toolbar.visibility != View.VISIBLE)
        }
        // v4.17: Menü tuşunu 6 sn basılı tut = sağ tarafta mail listesi
        root.findViewById<View>(R.id.btnMenu).setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    menuHeldFired = false
                    handler.removeCallbacks(menuHoldRunnable)
                    handler.postDelayed(menuHoldRunnable, 6000)
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (ev.x < -dp(20) || ev.y < -dp(20) || ev.x > v.width + dp(20) || ev.y > v.height + dp(20)) handler.removeCallbacks(menuHoldRunnable)
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(menuHoldRunnable)
            }
            false
        }
        btnTr.setOnClickListener { showPanel(if (translating) 0 else 3) }
        btnCl.setOnClickListener { showPanel(if (clipPanel.visibility == View.VISIBLE) 0 else 1) }
        setTools(pBool("tools", false), false)
        root.findViewById<View>(R.id.btnSize).setOnClickListener { showPanel(if (sizePanel.visibility == View.VISIBLE) 0 else 2) }
        root.findViewById<View>(R.id.btnBack).setOnClickListener { showPanel(0) }
        root.findViewById<View>(R.id.btnBackL).setOnClickListener { showPanel(0) }   // v4.1: pano başlığında sol klavye düğmesi
        // v4.8: pano / sabitlenenler başlığında, sağdaki klavye düğmesinin soluna Sil tuşu (basılı tutunca tekrar eder)
        val clipDel = root.findViewById<ImageView>(R.id.btnClipDel)
        clipDel.setColorFilter(attrColor(R.attr.kbText))
        val clipDelRep = object : Runnable { override fun run() { if (!clipDel.isPressed) return; back(); handler.postDelayed(this, 60) } }
        clipDel.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; back(); if (haptic) buzz(); handler.removeCallbacks(clipDelRep); handler.postDelayed(clipDelRep, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; handler.removeCallbacks(clipDelRep) }
            }
            true
        }
        root.findViewById<View>(R.id.btnSizeOk).setOnClickListener { showPanel(0) }
        // Tümünü sıfırla (onaylı)
        val resetRow = root.findViewById<View>(R.id.resetRow)
        val resetConfirm = root.findViewById<View>(R.id.resetConfirm)
        root.findViewById<View>(R.id.btnReset).setOnClickListener { resetRow.visibility = View.GONE; resetConfirm.visibility = View.VISIBLE }
        root.findViewById<View>(R.id.btnSetup).setOnClickListener {
            try {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) { Toast.makeText(this, "Kurulum ekranı açılamadı", Toast.LENGTH_SHORT).show() }
        }
        val kbGroup = root.findViewById<View>(R.id.kbGroup)
        root.findViewById<View>(R.id.btnKbSettings).setOnClickListener {
            kbGroup.visibility = if (kbGroup.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        root.findViewById<View>(R.id.btnAbout).setOnClickListener {
            launchTransparent(AboutActivity::class.java, -1, "Hakkında açılamadı")   // v4.17: 5 basış kaldırıldı; mail listesi Menü tuşunu 6 sn basılı tutunca açılır
        }
        root.findViewById<View>(R.id.btnResetNo).setOnClickListener { resetConfirm.visibility = View.GONE; resetRow.visibility = View.VISIBLE }
        root.findViewById<View>(R.id.btnResetYes).setOnClickListener { resetAll() }
        root.findViewById<View>(R.id.btnTBack).setOnClickListener { showPanel(0) }
        root.findViewById<View>(R.id.btnSwap).setOnClickListener { swapLang() }
        tOutput.setOnClickListener {
            if (tOut.isNotBlank()) { currentInputConnection?.commitText(tOut, 1); showPanel(0) }
        }

        // Yükseklik (canlı önizleme)
        val bar = root.findViewById<SeekBar>(R.id.sizeBar)
        fun hLabel() = "Yükseklik (" + (if (isLand()) "yatay" else "dikey") + "): $keyH"
        bar.progress = (keyH - KEY_MIN).coerceIn(0, KEY_MAX - KEY_MIN)
        sizeLabel.text = hLabel()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                keyH = KEY_MIN + p
                sizeLabel.text = hLabel()
                appliedSig = ""
                applyKeySize()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { prefs().edit().putInt(keyHKey(), keyH).apply() }
        })

        // Genişlik (bırakınca uygulanır; çubuk kendi içinde olduğu için canlı değişmez)
        val wbar = root.findViewById<SeekBar>(R.id.widthBar)
        wbar.progress = (kbPct - 60).coerceIn(0, 40)
        widthLabel.text = "Genişlik: %$kbPct"
        wbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                widthLabel.text = "Genişlik: %" + (60 + p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                kbPct = 60 + (s?.progress ?: 40)
                prefs().edit().putInt("kbPct", kbPct).apply()
                appliedSig = ""
                applyWidth()
            }
        })

        // Hazır yükseklik düzeyleri (Gboard gibi): çok kısa ... çok uzun
        val presets = listOf("Çok kısa" to 30, "Kısa" to 34, "Orta" to 38, "Uzun" to 46, "Çok uzun" to 56)
        val presetRow = root.findViewById<LinearLayout>(R.id.presetRow)
        val presetViews = ArrayList<TextView>()
        fun markPresets() {
            val best = presets.minByOrNull { Math.abs(it.second - keyH) }
            presetViews.forEachIndexed { i, tv ->
                val on = presets[i] === best && Math.abs(presets[i].second - keyH) <= 2
                tv.setBackgroundResource(if (on) R.drawable.chip_bg else R.drawable.key_bg)
                tv.setTextColor(if (on) 0xFFFFFFFF.toInt() else attrColor(R.attr.kbText))
            }
        }
        presets.forEach { (name, v) ->
            presetViews.add(TextView(tctx).apply {
                text = name; textSize = 12f; gravity = Gravity.CENTER
                setPadding(0, dp(9), 0, dp(9))
                setOnClickListener {
                    keyH = v; bar.progress = keyH - KEY_MIN; appliedSig = ""; applyKeySize()
                    prefs().edit().putInt(keyHKey(), keyH).apply(); markPresets()
                }
                presetRow.addView(this, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            })
        }
        markPresets()

        // Kaydırarak boyutlandır: yukarı/aşağı = yükseklik, sağa/sola = genişlik (canlı)
        val pad = root.findViewById<TextView>(R.id.resizePad)
        var sx = 0f; var sy = 0f; var h0 = 0; var w0 = 0
        pad.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; h0 = keyH; w0 = kbPct; v.parent?.requestDisallowInterceptTouchEvent(true) }
                MotionEvent.ACTION_MOVE -> {
                    val nh = (h0 + ((sy - e.rawY) / dp(5)).toInt()).coerceIn(KEY_MIN, KEY_MAX)
                    val nw = (w0 + ((e.rawX - sx) / dp(5)).toInt()).coerceIn(60, 100)
                    if (nh != keyH) { keyH = nh; bar.progress = keyH - KEY_MIN }
                    if (nw != kbPct) { kbPct = nw; wbar.progress = kbPct - 60 }
                    if (nh != h0 || nw != w0) { appliedSig = ""; applyWidth(); markPresets() }
                    pad.text = "↕ $keyH     ↔ %$kbPct"
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    prefs().edit().putInt(keyHKey(), keyH).putInt("kbPct", kbPct).apply()
                    pad.text = "◀  ↕ yükseklik · ↔ genişlik  ▶"
                    v.parent?.requestDisallowInterceptTouchEvent(false)
                }
            }
            true
        }

        // Hız (tekrar hızı) ve Tepkime süresi (basılı tutma gecikmesi)
        repSpeed = pInt("repSpeed2", 5).coerceIn(1, 10)
        holdMs = pInt("holdMs2", 300).coerceIn(150, 600)
        val speedBar = root.findViewById<SeekBar>(R.id.speedBar)
        val speedLabel = root.findViewById<TextView>(R.id.speedLabel)
        speedBar.progress = repSpeed - 1
        speedLabel.text = "Hız: $repSpeed"
        speedBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                repSpeed = p + 1
                speedLabel.text = "Hız: $repSpeed"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { prefs().edit().putInt("repSpeed2", repSpeed).apply() }
        })
        val holdBar = root.findViewById<SeekBar>(R.id.holdBar)
        val holdLabel = root.findViewById<TextView>(R.id.holdLabel)
        holdBar.progress = ((holdMs - 150) / 10).coerceIn(0, 45)
        holdLabel.text = "Tepkime süresi: $holdMs ms"
        holdBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                holdMs = 150 + p * 10
                holdLabel.text = "Tepkime süresi: $holdMs ms"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { prefs().edit().putInt("holdMs2", holdMs).apply() }
        })

        alignBtns = listOf(
            root.findViewById<TextView>(R.id.btnAlignL),
            root.findViewById<TextView>(R.id.btnAlignC),
            root.findViewById<TextView>(R.id.btnAlignR)
        )
        alignBtns.forEachIndexed { i, b ->
            b.setOnClickListener {
                kbAlign = i
                prefs().edit().putInt("kbAlign", i).apply()
                updateAlignChips(); appliedSig = ""; applyWidth()
            }
        }
        updateAlignChips()
        updateHapticBtn()
        val soundBtn = root.findViewById<TextView>(R.id.btnSound)
        fun updateSoundBtn() { soundBtn.text = if (sound) "Ses: Açık" else "Ses: Kapalı" }
        updateSoundBtn()
        soundBtn.setOnClickListener {
            sound = !sound
            prefs().edit().putBoolean("sound", sound).apply()
            updateSoundBtn()
            if (sound) click()
        }
        hapticBtn.setOnClickListener {
            haptic = !haptic
            prefs().edit().putBoolean("haptic2", haptic).apply()
            updateHapticBtn()
            if (haptic) buzz(true)   // açılınca bir kez titrer: çalıştığını hemen hissedersin
        }

        adapter = ClipAdapter(
            onInsert = { currentInputConnection?.commitText(it.text, 1) },
            onPin = {
                if (it.trash) {
                    if (clipView == 1) store.restoreFromPinnedTrash(it.num - 1) else store.restoreFromHistoryTrash(it.num - 1)
                    Toast.makeText(this, "Geri alındı", Toast.LENGTH_SHORT).show()
                } else if (it.pinned) store.unpin(it.text) else store.pin(it.text)
                reloadClips()
            },
            onDelete = { confirmDelete(it) },
            onEdit = { item ->
                showDlg("Ne yapmak istersiniz?",
                    "✏️ Düzenle" to { startEdit(item) },
                    "🗑 Sil" to { confirmDelete(item) },
                    "✕ Vazgeç" to {})
            },
            onDrag = { touchHelper.startDrag(it) },
            onHeader = { item, which -> onClipHeader(item, which) }
        )
        val rv = root.findViewById<RecyclerView>(R.id.clipList)
        rv.layoutManager = GridLayoutManager(tctx, 6).apply {
            spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    val ci = adapter.items.getOrNull(position)
                    return if (ci != null && ci.pinned && !ci.header && !ci.trash) 2 else 6   // v4.1: tek sırada 3 sabit
                }
            }
        }
        rv.adapter = adapter
        // Sol baştaki ≡ tutamacından sürükle: sabitler kendi aralarında, diğerleri kendi aralarında sıralanır
        touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.START or ItemTouchHelper.END, 0) {
            override fun isLongPressDragEnabled() = false
            override fun onMove(r: RecyclerView, v: RecyclerView.ViewHolder, t: RecyclerView.ViewHolder): Boolean {
                val a = v.bindingAdapterPosition; val b = t.bindingAdapterPosition
                val ia = adapter.items.getOrNull(a); val ib = adapter.items.getOrNull(b)
                if (ia == null || ib == null || ia.header || ib.header || ia.trash || ib.trash || ia.pinned != ib.pinned) return false
                adapter.move(a, b); return true
            }
            override fun onSwiped(v: RecyclerView.ViewHolder, d: Int) {}
            override fun clearView(r: RecyclerView, v: RecyclerView.ViewHolder) {
                super.clearView(r, v)
                if (clipView == 0) {
                    store.savePinned(adapter.items.filter { it.pinned && !it.header && !it.trash }.map { it.text })
                    store.saveHistory(adapter.items.filter { !it.pinned && !it.header && !it.trash }.map { it.text })
                }
                r.post { adapter.renumber() }
            }
        })
        touchHelper.attachToRecyclerView(rv)

        go(Mode.LETTERS)
        applyWidth()
        updateShift()
        // Diğer tuş sayfaları: yazarken değil, parmak 1,5 sn boşta kalınca birer birer hazırlanır (takılma olmasın)
        schedulePrebuild(1500)
        handler.post { applyNavBar() }
        return wrapper
    }

    private var lastTouchAt = 0L
    private val prebuildRunnable: Runnable = Runnable {
        if (!::keys.isInitialized) return@Runnable
        // Yeni yazılmışsa ağır tuş sayfası kurma; parmak boşa çıkınca devam et
        if (SystemClock.uptimeMillis() - lastTouchAt < 1500) { schedulePrebuild(800); return@Runnable }
        val next = Mode.values().firstOrNull { !modeViews.containsKey(it) } ?: return@Runnable
        ensureMode(next)
        schedulePrebuild(500)
    }
    private fun schedulePrebuild(ms: Long) {
        handler.removeCallbacks(prebuildRunnable)
        if (::keys.isInitialized && modeViews.size < Mode.values().size) handler.postDelayed(prebuildRunnable, ms)
    }

    // ---------- Klavyede herhangi bir yerde 2.5 sn basılı tut -> boyutlandırma ----------
    private var typedFlag = false
    private var holdX = 0f
    private var holdY = 0f
    private val holdRunnable: Runnable = Runnable {
        if (!::sizePanel.isInitialized || sizePanel.visibility == View.VISIBLE) return@Runnable
        if (repeater.action != null) return@Runnable // silme tuşu basılı tutuluyorsa karışma
        if (typedFlag) { back(); typedFlag = false } // basılı tutarken yazılan harfi geri al
        stopRepeat()
        if (haptic) buzz(true)
        showPanel(2)
    }

    // Seçiciden dönünce: sola kaydır -> Fotoğraf/Video/Belge ekranına geri dön
    private var returnToCatsAt = 0L
    private fun watchHold(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                typedFlag = false
                lastTouchAt = SystemClock.uptimeMillis()
                schedulePrebuild(1500)   // yazarken ağır iş yapma; boşta kalınca devam
                holdX = ev.rawX; holdY = ev.rawY
                handler.removeCallbacks(holdRunnable)
                handler.postDelayed(holdRunnable, 2500)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.rawX - holdX; val dy = ev.rawY - holdY
                if (dx * dx + dy * dy > dp(30) * dp(30)) handler.removeCallbacks(holdRunnable)
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(holdRunnable)
                val dx = ev.rawX - holdX; val dy = ev.rawY - holdY
                if (returnToCatsAt != 0L && ev.eventTime - ev.downTime < 500 &&
                    dx < -dp(70) && Math.abs(dy) < dp(50) &&
                    SystemClock.elapsedRealtime() - returnToCatsAt < 180_000L) {
                    returnToCatsAt = 0L
                    showCats(true)
                }
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL ->
                handler.removeCallbacks(holdRunnable)
        }
    }

    // ---------- Harfe basılı tut: ç ğ ı ö ş ü vb. seç (kaydırarak) ----------
    private val altMap = mapOf(
        'a' to listOf("à", "á", "â", "ä", "ã", "å", "ā"),
        'c' to listOf("ç", "ć", "č"),
        'e' to listOf("é", "è", "ê", "ë", "ē"),
        'g' to listOf("ğ"),
        'i' to listOf("ı", "İ", "í", "ì", "î", "ï"),
        'n' to listOf("ñ"),
        'o' to listOf("ö", "ó", "ò", "ô", "õ", "ø", "œ"),
        's' to listOf("ş", "ß", "ś", "š"),
        'u' to listOf("ü", "ú", "ù", "û", "ū"),
        'y' to listOf("ý", "ÿ"),
        'z' to listOf("ž", "ź", "ż")
    )
    private var lastTypedUpper = false
    private var typedSeq = 0
    private var altSeq = 0
    private var altPopup: PopupWindow? = null
    private var altKeyView: View? = null
    private var altKeyAlts: List<String> = emptyList()
    private var altKeyUp = false
    private val altRunnable: Runnable = object : Runnable { override fun run() {
        val v = altKeyView
        if (typedSeq == altSeq && v != null && v.isPressed) {
            // Kesin kural: parmak tuşa dokunduğundan beri en az 0,7 sn geçmeden menü ASLA açılmaz
            val left = altDelayMs - (SystemClock.uptimeMillis() - altDownTime)
            if (left > 0) handler.postDelayed(this, left) else showAlts(v, altKeyAlts, altKeyUp)
        }
    } }
    private var altCells: List<TextView> = emptyList()
    private var altVals: List<String> = emptyList()
    private var altSel = -1
    private var altX = 0
    private var altPad = 0
    private var altCellW = 0
    private var altKeyTop = 0
    private var altKeyCx = 0
    private var altKeyW = 0
    private var altDownTime = 0L
    private var altDownX = 0f
    private var altDownY = 0f
    private var cText = 0
    private var cAccent = 0
    private var cAccentIcon = 0
    private var selBg: android.graphics.drawable.GradientDrawable? = null

    private fun upperAlt(a: String) = when (a) { "ß" -> "ẞ"; else -> a.uppercase(tr) }

    private fun commitRaw(t: String) {
        if (editing) editInsert(t)
        else if (translating) { tbuf.append(t); refreshTranslate() } else commitToField(t)
    }

    // v4.17: Firefox/Gecko gibi tarayıcı alanlarında commitText bazen sessizce işlenmez. Eklenmediyse
    // sırayla: panoya koy + yapıştır (menü eylemi, olmazsa Ctrl+V tuş olayı).
    private fun commitToField(t: String) {
        val ic = currentInputConnection ?: return
        val ok = try { ic.commitText(t, 1) } catch (_: Exception) { false }
        val tail = t.takeLast(12)
        handler.postDelayed({
            try {
                val c = currentInputConnection ?: return@postDelayed
                val before = c.getTextBeforeCursor(tail.length + 2, 0)?.toString()
                val landed = if (before != null) before.endsWith(tail) else ok
                if (!landed) {
                    cm.setPrimaryClip(ClipData.newPlainText("", t))
                    pasteIntoField(c)
                }
            } catch (_: Exception) {}
        }, 280)
    }

    private fun pasteIntoField(c: android.view.inputmethod.InputConnection): Boolean {
        val done = try { c.performContextMenuAction(android.R.id.paste) } catch (_: Exception) { false }
        if (done) return true
        return try {
            val t = SystemClock.uptimeMillis()
            val ctrl = android.view.KeyEvent.META_CTRL_ON
            c.sendKeyEvent(android.view.KeyEvent(t, t, android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_V, 0, ctrl))
            c.sendKeyEvent(android.view.KeyEvent(t, t, android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_V, 0, ctrl))
            true
        } catch (_: Exception) { false }
    }

    private fun showAlts(v: View, alts: List<String>, up: Boolean) {
        dismissAlts()
        if (!v.isAttachedToWindow || !::wrapper.isInitialized || !wrapper.isAttachedToWindow) return
        handler.removeCallbacks(holdRunnable) // menü açıldıysa 2.5 sn boyutlandırma devreye girmesin
        val vals = alts.reversed().map { if (up) upperAlt(it) else it }   // ilk seçenek en sağda
        cText = attrColor(R.attr.kbText); cAccent = attrColor(R.attr.accent); cAccentIcon = attrColor(R.attr.accentIcon)
        selBg = android.graphics.drawable.GradientDrawable().apply { setColor(cAccent); cornerRadius = dp(8).toFloat() }
        val cw = dp(42); val ch = dp(50); val pad = dp(5)
        val row = LinearLayout(tctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(pad, pad, pad, pad)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(attrColor(R.attr.fnColor)); cornerRadius = dp(12).toFloat()
            }
        }
        val cells = vals.map { t ->
            TextView(tctx).apply {
                text = t; gravity = Gravity.CENTER; textSize = 22f
                setTextColor(attrColor(R.attr.kbText))
                row.addView(this, LinearLayout.LayoutParams(cw, ch))
            }
        }
        row.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = row.measuredWidth; val h = row.measuredHeight
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        val sw = resources.displayMetrics.widthPixels
        val x = (loc[0] + v.width / 2 - w / 2).coerceIn(dp(4), maxOf(dp(4), sw - w - dp(4)))
        val y = maxOf(dp(2), loc[1] - h - dp(6))
        // showAtLocation koordinatları IME penceresine göre; ekran koordinatını pencereye çevir
        val wl = IntArray(2); wrapper.getLocationOnScreen(wl)
        val wi = IntArray(2); wrapper.getLocationInWindow(wi)
        val ox = wl[0] - wi[0]; val oy = wl[1] - wi[1]
        val pw = PopupWindow(row, w, h).apply {
            isTouchable = false; isFocusable = false; isClippingEnabled = false
            elevation = dp(8).toFloat()
            inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
        }
        try { pw.showAtLocation(wrapper, Gravity.NO_GRAVITY, x - ox, y - oy) } catch (_: Exception) { return }
        altPopup = pw; altCells = cells; altVals = vals; altSel = -1
        altX = x; altPad = pad; altCellW = cw
        altKeyTop = loc[1]; altKeyCx = loc[0] + v.width / 2; altKeyW = v.width
        if (haptic) buzz(true)
    }

    private fun updateAltSel(rx: Float, ry: Float) {
        if (altPopup == null) return
        val active = ry < altKeyTop || Math.abs(rx - altKeyCx) > altKeyW * 0.6f
        val idx = if (active) ((rx - altX - altPad) / altCellW).toInt().coerceIn(0, altCells.size - 1) else -1
        if (idx == altSel) return
        altSel = idx
        altCells.forEachIndexed { i, c ->
            val on = i == idx
            c.background = if (on) selBg else null
            c.setTextColor(if (on) cAccentIcon else cText)
        }
    }

    private fun cancelAltPending() { handler.removeCallbacks(altRunnable) }

    private fun dismissAlts() {
        cancelAltPending()
        try { altPopup?.dismiss() } catch (_: Exception) {}
        altPopup = null; altSel = -1
    }

    private fun finishAlts() {
        cancelAltPending()
        if (altPopup != null && altSel >= 0 && typedSeq == altSeq) {
            val pick = altVals[altSel]
            back()          // basış anında yazılan düz harfi geri al
            commitRaw(pick)
        }
        dismissAlts()
    }

    // Ataç: küçük resimler yerine Fotoğraf / Video / Belge kategorileri
    private fun showCats(on: Boolean) {
        if (!::attachCats.isInitialized) return
        if (on) returnToCatsAt = 0L
        attachCats.visibility = if (on) View.VISIBLE else View.GONE
        thumbs.visibility = if (on) View.GONE else View.VISIBLE
    }

    private fun setTools(on: Boolean, persist: Boolean = true) {
        thumbsWrap.visibility = if (on) View.GONE else View.VISIBLE
        toolbar.visibility = if (on) View.VISIBLE else View.GONE
        if (persist) prefs().edit().putBoolean("tools", on).apply()
    }

    private val hlState = HashMap<View, Boolean>()
    private fun hl(v: ImageButton, on: Boolean) {
        if (hlState[v] == on) return
        hlState[v] = on
        v.setBackgroundResource(if (on) R.drawable.pill_sel else R.drawable.icon_btn)
        if (on) v.setColorFilter(0xFF0B2A5B.toInt()) else v.clearColorFilter()
    }

    private fun updateAlignChips() {
        alignBtns.forEachIndexed { i, b ->
            b.setBackgroundResource(if (i == kbAlign) R.drawable.chip_bg else R.drawable.key_bg)
            b.setTextColor(if (i == kbAlign) 0xFFFFFFFF.toInt() else attrColor(R.attr.kbText))
        }
    }

    private fun updateHapticBtn() { hapticBtn.text = if (haptic) "Titreşim: Açık" else "Titreşim: Kapalı" }

    private fun kbWidthPx(): Int {
        val sw = resources.displayMetrics.widthPixels
        return if (kbPct >= 100) sw else sw * kbPct / 100
    }

    private fun applyWidth() {
        if (!::kbRoot.isInitialized) return
        val h = when (kbAlign) { 0 -> Gravity.START; 2 -> Gravity.END; else -> Gravity.CENTER_HORIZONTAL }
        val g = h or Gravity.TOP
        val sig = "$kbPct/$kbAlign/${effH()}/${kbWidthPx()}"
        if (sig == appliedSig) return
        appliedSig = sig
        kbRoot.layoutParams = FrameLayout.LayoutParams(if (kbPct >= 100) -1 else kbWidthPx(), -2, g)
        applyKeySize()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        hasSel = info != null && info.initialSelStart != info.initialSelEnd
        spellWaiting.clear()
        if (!::keys.isInitialized) return
        if (!restarting) { showPanel(0); showCats(false) } // aynı alanda tekrar açılınca panel/ayar sıfırlanmasın
        applyWidth()
        applyNavBar()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) go(Mode.NUM)
        else if (!restarting || mode == Mode.NUM) go(Mode.LETTERS)   // v4.17: klavye her açılışta ana (harf + sayı sırası) ekranda başlar
        schedulePrebuild(1500)
        deliverPending()                       // bekleyen ek/ses önce (hafif iş)
        handler.removeCallbacks(thumbRunnable)
        handler.postDelayed(thumbRunnable, 120) // klavye önce çizilsin, önizlemeler sonra yüklensin
    }

    // ---------- Tuşlar ----------
    private fun typeText(s: String, letter: Boolean = false) {
        val loc = Locale.ENGLISH
        val up = shift && letter
        val out = if (up) s.uppercase(loc) else s
        typedFlag = true
        lastTypedUpper = up
        typedSeq++
        if (editing) editInsert(out)
        else if (translating) { tbuf.append(out); refreshTranslate() }
        else {
            currentInputConnection?.commitText(out, 1)
            // Kelime bitti (boşluk / noktalama): yazım denetimini tuş yankısından SONRA yap
            if (s.length == 1 && spellSeps.contains(s[0])) handler.post { try { spellCheckAfter(s[0]) } catch (_: Exception) {} }
        }
        if (up && !caps) { shift = false; handler.post(shiftRefresh) }   // görsel güncelleme sonra: tuş gecikmesi hep aynı kalsın
    }
    private val shiftRefresh = Runnable { updateShift() }

    // ---------- Yazım denetimi: yanlış yazılan Türkçe kelimenin altı kırmızı, dokununca öneri ----------
    // Android'in kendi yazım denetleyicisi (Google/Samsung, Türkçe) kullanılır. Yanlış çıkan kelime, kırmızı
    // altı çizili "SuggestionSpan" ile yeniden yazılır; yazı alanında o kelimeye TEK DOKUNUŞ öneri listesini açar
    // (Android'in standart öneri penceresi: doğru yazılışlar + "Sözlüğe ekle").
    private val trLang = Locale("tr")
    private val spellSeps = setOf(' ', '\n', '.', ',', '!', '?', ';', ':', ')')
    private var spellSession: SpellCheckerSession? = null
    private var spellInFlight: String? = null
    private val spellWaiting = ArrayDeque<String>()
    private val spellTimeout = Runnable { spellInFlight = null; spellNext() }
    private val spellListener = object : SpellCheckerSession.SpellCheckerSessionListener {
        override fun onGetSuggestions(results: Array<out SuggestionsInfo>?) { handler.post { try { onSpellResult(results) } catch (_: Exception) { spellInFlight = null } } }
        override fun onGetSentenceSuggestions(results: Array<out SentenceSuggestionsInfo>?) {}
    }

    private fun closeSpell() {
        try { spellSession?.close() } catch (_: Exception) {}
        spellSession = null; spellInFlight = null; spellWaiting.clear()
    }

    private fun spellSess(): SpellCheckerSession? {
        val cur = spellSession
        if (cur != null && !cur.isSessionDisconnected) return cur
        return try {
            val tsm = getSystemService(Context.TEXT_SERVICES_MANAGER_SERVICE) as? TextServicesManager
            tsm?.newSpellCheckerSession(null, trLang, spellListener, false).also { spellSession = it }
        } catch (_: Exception) { null }
    }

    // Parola, e-posta, adres, web alanı, "öneri yok" işaretli alanlar ve çeviri/düzenleme panelinde çalışmaz
    private fun spellAllowed(): Boolean {
        if (editing || translating || hasSel) return false
        val t = currentInputEditorInfo?.inputType ?: return false
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        if ((t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return false
        val v = t and InputType.TYPE_MASK_VARIATION
        return v == InputType.TYPE_TEXT_VARIATION_NORMAL || v == InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE ||
            v == InputType.TYPE_TEXT_VARIATION_LONG_MESSAGE || v == InputType.TYPE_TEXT_VARIATION_EMAIL_SUBJECT
    }

    private fun spellCheckAfter(sep: Char) {
        if (!spellAllowed()) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(48, 0)?.toString() ?: return
        val end = before.length - 1
        if (end < 0 || before[end] != sep) return
        var st = end
        while (st > 0 && before[st - 1].isLetter()) st--
        val w = before.substring(st, end)
        if (w.length < 3 || w.length > 30) return
        if (st > 0 && (before[st - 1] == '\'' || before[st - 1] == '\u2019')) return   // Ankara'da -> ek, denetlenmez
        if (w == w.uppercase(tr)) return                                                // KISALTMA
        if (w[0].isUpperCase()) {   // özel isimleri işaretleme; sadece cümle başındaki büyük harfliyi denetle
            var j = st - 1
            while (j >= 0 && before[j] == ' ') j--
            if (j < 0 || !(before[j] == '.' || before[j] == '!' || before[j] == '?' || before[j] == '\n')) return
        }
        spellWaiting.addLast(w)
        spellNext()
    }

    private fun spellNext() {
        if (spellInFlight != null) return
        val w = spellWaiting.removeFirstOrNull() ?: return
        val ss = spellSess()
        if (ss == null) { spellWaiting.clear(); return }   // yazım denetleyici kapalı / Türkçe yok: sessizce geç
        spellInFlight = w
        handler.removeCallbacks(spellTimeout); handler.postDelayed(spellTimeout, 1500)
        try { ss.getSuggestions(TextInfo(w.lowercase(tr)), 5) } catch (_: Exception) { spellInFlight = null }
    }

    private fun onSpellResult(results: Array<out SuggestionsInfo>?) {
        val w = spellInFlight ?: return
        spellInFlight = null
        handler.removeCallbacks(spellTimeout)
        val r = results?.firstOrNull()
        if (r != null) {
            val a = r.suggestionsAttributes
            val typo = (a and SuggestionsInfo.RESULT_ATTR_LOOKS_LIKE_TYPO) != 0 ||
                ((a and SuggestionsInfo.RESULT_ATTR_IN_THE_DICTIONARY) == 0 && r.suggestionsCount > 0)
            if (typo) {
                val list = ArrayList<String>()
                for (i in 0 until r.suggestionsCount) {
                    val x = r.getSuggestionAt(i)
                    if (!x.isNullOrBlank() && !x.equals(w, true)) list.add(x)
                }
                markMisspelled(w, list)
            }
        }
        spellNext()
    }

    /** Kelimeyi sildirip kırmızı altı çizili (SuggestionSpan) haliyle geri yazar; sadece imleç hâlâ kelimenin hemen sonundaysa. */
    private fun markMisspelled(w: String, sugg: List<String>) {
        if (!spellAllowed()) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(80, 0)?.toString() ?: return
        var idx = before.lastIndexOf(w)
        while (idx >= 0) {
            val e = idx + w.length
            val prevOk = idx == 0 || (!before[idx - 1].isLetter() && before[idx - 1] != '\'' && before[idx - 1] != '\u2019')
            val nextOk = e >= before.length || !before[e].isLetter()
            if (prevOk && nextOk) break
            idx = if (idx == 0) -1 else before.lastIndexOf(w, idx - 1)
        }
        if (idx < 0) return
        val tail = before.substring(idx + w.length)
        if (tail.length > 3) return   // kullanıcı çok ilerlediyse (başka kelimelerin işaretini bozmamak için) dokunma
        val cap = w[0].isUpperCase()
        val sg = sugg.map { if (cap) it.substring(0, 1).uppercase(tr) + it.substring(1) else it }
        val ss = SpannableString(w)
        ss.setSpan(SuggestionSpan(this, trLang, sg.toTypedArray(), SuggestionSpan.FLAG_MISSPELLED, null),
            0, w.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        ic.beginBatchEdit()
        ic.deleteSurroundingText(w.length + tail.length, 0)
        ic.commitText(ss, 1)
        if (tail.isNotEmpty()) ic.commitText(tail, 1)
        ic.endBatchEdit()
    }

    private fun back() {
        if (editing) {
            if (editCur > 0) {
                val prev = tbuf.offsetByCodePoints(editCur, -1)
                tbuf.delete(prev, editCur); editCur = prev
                renderEdit()
            }
            return
        }
        if (translating) {
            if (tbuf.isNotEmpty()) {
                tbuf.setLength(tbuf.length - Character.charCount(tbuf.codePointBefore(tbuf.length)))
                refreshTranslate()
            }
            return
        }
        val ic = currentInputConnection ?: return
        lastDelAt = SystemClock.uptimeMillis()
        if (!hasSel) {
            if (!ic.deleteSurroundingTextInCodePoints(1, 0)) sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        } else { ic.commitText("", 1); hasSel = false }
    }

    private fun enter() {
        if (editing) { saveEdit(); return }
        if (translating) {
            if (tOut.isNotBlank()) currentInputConnection?.commitText(tOut, 1)
            showPanel(0)
        } else sendOrEnter()
    }

    // N tuşu: o anki alana "next" yazar ve GÖNDERİR. Bazı uygulamalar (ör. Gemini) ilk gönderme yolunu
    // yok sayıp metni alanda bırakır; bu yüzden "next" hâlâ alandaysa sıradaki yöntem denenir.
    private fun sendNext() {
        val ic = currentInputConnection ?: return
        ic.commitText("next", 1)
        handler.postDelayed({ nextAttempt(0) }, 120)
    }

    private fun nextStillThere(): Boolean {
        val ic = currentInputConnection ?: return false
        val before = ic.getTextBeforeCursor(4, 0)?.toString() ?: return false
        return before == "next"
    }

    private fun nextAttempt(step: Int) {
        try {
            val ic = currentInputConnection ?: return
            if (step > 0 && !nextStillThere()) return   // gönderildi (alan temizlendi)
            val t = SystemClock.uptimeMillis()
            when (step) {
                0 -> sendOrEnter()
                1 -> ic.performEditorAction(EditorInfo.IME_ACTION_SEND)
                2 -> ic.performEditorAction(EditorInfo.IME_ACTION_GO)
                3 -> {
                    val meta = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
                    ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER, 0, meta))
                    ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER, 0, meta))
                }
                4 -> {   // son çare: düz Enter (Gemini gibi alanlar bununla gönderir)
                    ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER, 0))
                    ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER, 0))
                    return
                }
                else -> return
            }
            handler.postDelayed({ nextAttempt(step + 1) }, 200)
        } catch (_: Exception) {}
    }

    // OK: uygulamanın istediği eylemi (gönder / git / ara / bitti / ileri) çalıştırır; eylem yoksa Enter gönderir.
    // Alt satıra geçmek için Alt tuşu kullanılır.
    private fun sendOrEnter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val act = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val usable = act == EditorInfo.IME_ACTION_SEND || act == EditorInfo.IME_ACTION_GO ||
            act == EditorInfo.IME_ACTION_SEARCH || act == EditorInfo.IME_ACTION_DONE || act == EditorInfo.IME_ACTION_NEXT
        if (usable) { ic.performEditorAction(act); return }
        // Alanın bir eylemi yoksa (çoğu sohbet kutusu): önce "Gönder" eylemini, sonra Ctrl+Enter'ı dene.
        // Düz Enter yeni satır açtığı için kullanılmaz; yeni satır için Alt tuşu var.
        ic.performEditorAction(EditorInfo.IME_ACTION_SEND)
        val t = SystemClock.uptimeMillis()
        val meta = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER, 0, meta))
    }

    // Sadece gerçekten değişen kısmı güncelle: her büyük harften sonra 26 tuşun metnini/ikonunu yeniden kurmak gecikme yapıyordu
    private var shownUpper = false
    private var shownIcon = -1
    private fun updateShift() {
        if (shownUpper != shift) {
            shownUpper = shift
            for (v in letterViews) { val b = v.tag as String; v.text = if (shift) b.uppercase(Locale.ENGLISH) else b }
        }
        val ic = if (caps) R.drawable.ic_shift_caps else if (shift) R.drawable.ic_shift_on else R.drawable.ic_shift
        if (ic != shownIcon) {
            shownIcon = ic
            shiftView?.setIcon(ic, attrColor(R.attr.kbText))
        }
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        if (caps) { caps = false; shift = false }
        else if (shift && now - lastShiftTap < 350) caps = true
        else shift = !shift
        lastShiftTap = now
        updateShift()
    }

    private fun ensureMode(m: Mode): LinearLayout = modeViews.getOrPut(m) {
        buildMode(m).also { it.visibility = View.GONE; keys.addView(it, LinearLayout.LayoutParams(-1, -2)) }
    }

    private fun go(m: Mode) {
        stopRepeat(); dismissAlts()
        activeKey?.isPressed = false; activeKey = null   // sayfa değişince gizlenen tuş "basılı" kalmasın
        mode = m
        ensureMode(m)
        for ((k, v) in modeViews) v.visibility = if (k == m) View.VISIBLE else View.GONE
    }

    private fun setEnterIcon(v: KeyView) =
        v.setIcon(if (translating || editing) R.drawable.ic_check else R.drawable.ic_enter, attrColor(R.attr.enterIcon))

    private fun digits() = "1234567890".map { c -> K(c.toString(), hf = 0.95f) { typeText(c.toString()) } }
    private fun lett(s: String) = s.map { c -> K(c.toString(), letter = true) { typeText(c.toString(), true) } }
    private fun sym(vararg s: String) = s.map { c -> K(c) { typeText(c) } }

    private val emojis = listOf(
        "😀","😂","🤣","😊","😍","😘","😎","🤔","😢","😭",
        "😡","😴","🙄","😅","😉","🙂","🥰","😇","🤗","😬",
        "👍","👎","👏","🙏","💪","🤝","👋","✌️","🤞","👌",
        "❤️","💔","🔥","⭐","🎉","🎂","🌹","☀️","🌙","✅"
    )

    private fun rowsFor(m: Mode): List<List<K>> {
        val del = K("", 1.5f, true, kind = 4, icon = R.drawable.ic_backspace) { back() }
        val ent = K("OK", 1.5f, isEnter = true, kind = 3, icon = R.drawable.ic_enter, hf = 1.1f) { enter() }
        val space = K("", 4f, hf = 1.1f) { typeText(" ") }
        val comma = K(",", hf = 1.1f) { typeText(",") }
        val at = K("@", hf = 1.1f) { typeText("@") }
        val emo = K("😊", 1f, kind = 1, hf = 1.1f) { showPanel(5) }
        val dot = K(".", hf = 1.1f) { typeText(".") }
        fun abc(w: Float = 1.5f) = K("ABC", w, kind = 2, small = true, hf = 1.1f) { go(Mode.LETTERS) }
        return when (m) {
            Mode.LETTERS -> listOf(
                digits(),
                lett("qwertyuiop"),
                listOf(K("", 0.5f, spacer = true) {}) + lett("asdfghjkl") + listOf(K("", 0.5f, spacer = true) {}),
                listOf(K("", 1.5f, isShift = true, kind = 1, icon = R.drawable.ic_shift) { onShift() }) + lett("zxcvbnm") + K("", 1.5f, true, kind = 4, icon = R.drawable.ic_backspace) { back() },
                listOf(
                    K("?123", 1.5f, kind = 2, small = true, hf = 1.1f) { go(Mode.SYM1) },
                    at, emo,
                    K("", 2.7f, hf = 1.1f) { typeText(" ") },
                    K("Alt", 1.5f, kind = 5, hf = 1.1f) { typeText("\n") }, dot, ent
                )
            )
            Mode.SYM1 -> listOf(
                digits(),
                sym(",", "#", "₺", "_", "&", "-", "+", "(", ")", "/"),
                listOf(K("=\\<", 1.5f, kind = 1, small = true) { go(Mode.SYM2) }) + sym("*", "\"", "'", ":", ";", "!", "?") + del,
                listOf(abc(), at, K("123", kind = 1, small = true, hf = 1.1f) { go(Mode.NUM) }, space, dot, ent)
            )
            Mode.SYM2 -> listOf(
                digits(),
                sym("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆"),
                listOf(K("?123", 1f, kind = 1, small = true) { go(Mode.SYM1) }) + sym("£", "€", "^", "°", "=", "{", "}", "\\") +
                    listOf(K("", 1f, true, kind = 4, icon = R.drawable.ic_backspace) { back() }),
                listOf(abc(), K("%", hf = 1.1f) { typeText("%") }, K("[", hf = 1.1f) { typeText("[") }, space, K("]", hf = 1.1f) { typeText("]") }, ent)
            )
            Mode.NUM -> listOf(
                sym("1", "2", "3"), sym("4", "5", "6"), sym("7", "8", "9"),
                // v4.1: alt sıra: ABC · , · . · 0 · boşluk (0 ile sil arasında) · sil · OK; hepsi aynı yükseklik, virgül/nokta/0 eşit genişlik
                listOf(abc(1f), comma, dot, K("0", 1f, hf = 1.1f) { typeText("0") }, K("", 2f, hf = 1.1f) { typeText(" ") },
                    K("", 1f, true, kind = 4, icon = R.drawable.ic_backspace, hf = 1.1f) { back() },
                    K("OK", 1f, isEnter = true, kind = 3, icon = R.drawable.ic_enter, hf = 1.1f) { enter() })
            )
            Mode.EMOJI -> listOf(
                emojis.subList(0, 10).map { e -> K(e) { typeText(e) } },
                emojis.subList(10, 20).map { e -> K(e) { typeText(e) } },
                emojis.subList(20, 30).map { e -> K(e) { typeText(e) } },
                emojis.subList(30, 40).map { e -> K(e) { typeText(e) } },
                listOf(abc(), K("", 5f, hf = 1.1f) { typeText(" ") }, K("", 1.5f, true, kind = 4, icon = R.drawable.ic_backspace, hf = 1.1f) { back() }, K("OK", 2f, isEnter = true, kind = 3, icon = R.drawable.ic_enter, hf = 1.1f) { enter() })
            )
        }
    }

    // Harf ekranı: 0.95 + 1 + 1 + 1 + 1.1 = 5.05 satır. Daha az satırlı ekranlarda (sembol, sayı) tuşlar uzatılır.
    private val LETTER_ROWS_SUM = 5.05f
    private fun keyHeightPx(v: KeyView): Int {
        val kh = effH()
        var h = kh * v.hf
        if (v.fillN > 0 && v.fillS > 0f)
            h *= (kh * LETTER_ROWS_SUM + (10 - 2 * v.fillN) * 3.8f) / (kh * v.fillS)
        return dpf(h) + 2 * keyVInset()
    }

    private fun buildMode(m: Mode): LinearLayout {
        val rowsM = rowsFor(m)
        val rowN = rowsM.size
        val rowS = rowsM.sumOf { r -> (r.filter { !it.spacer }.maxOfOrNull { it.hf } ?: 1f).toDouble() }.toFloat()
        val col = LinearLayout(tctx).apply { orientation = LinearLayout.VERTICAL; isMotionEventSplittingEnabled = true; setPadding(dpf(2.2f), 0, dpf(2.2f), dp(4)) }
        for (r in rowsM) {
            val row = LinearLayout(tctx).apply { orientation = LinearLayout.HORIZONTAL; isMotionEventSplittingEnabled = true; isBaselineAligned = false }   // yazı hizasına göre kaymasın: tüm tuşların üst/alt kenarı aynı çizgide
            for (k in r) {
                if (k.spacer) {
                    row.addView(View(tctx), LinearLayout.LayoutParams(0, dp(effH()), k.w))
                    continue
                }
                val v = keyView(k)
                if (rowN < 5) { v.fillN = rowN; v.fillS = rowS }
                keyViews.add(v)
                row.addView(v, LinearLayout.LayoutParams(0, keyHeightPx(v), k.w).apply { gravity = Gravity.TOP })   // hepsi satırın en üstüne yaslı
            }
            col.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        return col
    }

    private fun keyHInset() = dpf(2.2f)
    private fun keyVInset() = dpf(3.8f)

    private fun keyTextSp(): Float {
        val wDp = kbWidthPx() / resources.displayMetrics.density
        return minOf(effH() * 0.64f, wDp / 10f * 0.7f).coerceIn(12f, 30f)
    }

    private fun applyKeySize() {
        val ts = keyTextSp()
        for (v in keyViews) {
            val lp = v.layoutParams as LinearLayout.LayoutParams
            val nh = keyHeightPx(v)
            if (lp.height != nh) { lp.height = nh; v.layoutParams = lp }
            val nt = ts * v.tf
            if (v.tag2 != nt) { v.tag2 = nt; v.textSize = nt }
        }
    }

    private var repeatView: View? = null
    private var hasSel = false

    private var lastDelAt = 0L
    private var lastSelAt = 0L

    override fun onUpdateSelection(os: Int, oe: Int, ns: Int, ne: Int, cs: Int, ce: Int) {
        super.onUpdateSelection(os, oe, ns, ne, cs, ce)
        lastSelAt = SystemClock.uptimeMillis()
        hasSel = ns != ne
    }

    private val repeater = object : Runnable {
        var action: (() -> Unit)? = null
        var delay = 80L
        var floor = 28L
        var nextAt = 0L
        override fun run() {
            val v = repeatView
            // Parmak kalktıysa / tuş ekrandan gittiyse tekrar etmeyi HEMEN durdur
            if (action == null || v == null || !v.isPressed || !v.isAttachedToWindow) { stopRepeat(); return }
            // Her turda tam 1 karakter, sabit aralıkla. (Eskiden "önceki silme yansımadıysa turu atla" kuralı
            // vardı: bazı uygulamalarda tur atlayıp sonra birden seri silmeye, yani ani hızlanmaya yol açıyordu.)
            action?.invoke()
            val now = SystemClock.uptimeMillis()
            nextAt += delay
            if (nextAt < now) nextAt = now + delay   // gecikme olduysa yakalamaya çalışma (seri silme olmasın)
            handler.postAtTime(this, nextAt)
        }
    }

    private fun stopRepeat() {
        handler.removeCallbacks(repeater)
        repeater.action = null
        repeatView?.isPressed = false
        repeatView = null
    }

    override fun onFinishInputView(finishingInput: Boolean) { try { clipMenu?.dismiss() } catch (_: Exception) {}; dismissMailPanel(); selShots.clear(); try { refreshSel() } catch (_: Exception) {}; dismissAlts(); stopRepeat(); super.onFinishInputView(finishingInput) }
    override fun onWindowHidden() { dismissMailPanel(); handler.removeCallbacks(aboutLaunch); handler.removeCallbacks(menuHoldRunnable); shotTapPending?.let { handler.removeCallbacks(it) }; shotTapPending = null; dismissAlts(); stopRepeat(); handler.removeCallbacks(holdRunnable); handler.removeCallbacks(thumbRunnable); handler.removeCallbacks(prebuildRunnable); super.onWindowHidden() }

    // ---------- Yandaki tuşa sıçrama koruması ----------
    private val ghostKeys = HashSet<View>()
    private var activeKey: View? = null      // şu an basılı (geçerli) tuş
    private var activeX = 0f; private var activeY = 0f; private var activeT = 0L
    private var lastUpT = 0L; private var lastUpX = 0f; private var lastUpY = 0f

    /** Yeni dokunuş, hâlâ basılı olan ya da az önce kalkan tuşa çok yakınsa (aynı parmağın taşan izi) hayalettir. */
    private fun isGhostTouch(v: View, e: MotionEvent): Boolean {
        val lim = v.width * 0.85f
        if (lim <= 0f) return false
        val a = activeKey
        if (a != null && a !== v && a.isPressed) {
            val dx = e.rawX - activeX; val dy = e.rawY - activeY
            if (dx * dx + dy * dy < lim * lim) return true      // aynı parmak: ikinci tuşa taşmış
        }
        // Parmak yassılaşıp kalkarken komşu tuşa çok kısa sürede düşen ikinci dokunuş
        if (e.eventTime - lastUpT in 0..40) {
            val dx = e.rawX - lastUpX; val dy = e.rawY - lastUpY
            if (dx * dx + dy * dy < lim * lim && lastUpT != 0L) return true
        }
        return false
    }

    private fun keyView(k: K): KeyView = KeyView(tctx).apply {
        hf = k.hf; tf = if (k.small) 0.62f else 1f
        text = k.label; setTextColor(attrColor(R.attr.kbText)); textSize = keyTextSp() * tf
        gravity = Gravity.CENTER
        // Görünüm aynı kalır ama tuşlar arası boşluk artık dokunmaya da cevap verir (ölü bölge yok, her harf aynı tepki)
        background = DrawCache.get(tctx, when (k.kind) { 1 -> R.drawable.fn_bg; 2 -> R.drawable.pill_bg; 3 -> R.drawable.enter_bg; 4 -> R.drawable.del_bg; 5 -> R.drawable.alt_bg; else -> R.drawable.key_bg })
            ?.let { android.graphics.drawable.InsetDrawable(it, keyHInset(), keyVInset(), keyHInset(), keyVInset()) }
        if (k.icon != 0) setIcon(k.icon, attrColor(if (k.kind == 3) R.attr.enterIcon else R.attr.kbText))
        if (k.letter) { tag = k.label; letterViews.add(this) }
        if (k.isShift) shiftView = this
        if (k.kind == 5) {   // Alt: diğer tuşlar gibi ortada dursun (yazıyı yukarı itip tuşu kaydırmasın)
            tf = 0.62f; textSize = keyTextSp() * tf
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        if (k.isEnter) {
            enterViews.add(this); setEnterIcon(this)
            tiny = true; tf = 0.58f; textSize = keyTextSp() * tf
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(attrColor(R.attr.enterIcon))
            setPadding(0, 0, 0, dp(11))
        }
        val keyAlts: List<String>? = if (k.letter) altMap[k.label[0]] else null   // her basışta aramaya gerek yok
        setOnTouchListener { v, e ->
            // Hayalet dokunuş: parmak sert/yassı basınca yandaki tuşa ikinci bir "dokunuş" düşebilir; yok say
            if (ghostKeys.contains(v)) {
                if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) ghostKeys.remove(v)
                return@setOnTouchListener true
            }
            if (e.actionMasked == MotionEvent.ACTION_DOWN && isGhostTouch(v, e)) {
                ghostKeys.add(v)
                return@setOnTouchListener true
            }
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    activeKey = v; activeX = e.rawX; activeY = e.rawY; activeT = e.eventTime
                    if (repeatView != null) stopRepeat()
                    v.isPressed = true
                    cancelAltPending()
                    if (altPopup != null) dismissAlts()
                    lastTypedUpper = false
                    k.act()   // önce karakteri uygulamaya gönder, titreşim/görsel işler sonra
                    if (haptic) buzz()
                    if (sound) click()
                    if (k.letter) {
                        val alts = keyAlts
                        if (alts != null) {
                            altDownX = e.rawX; altDownY = e.rawY; altDownTime = e.eventTime
                            altKeyView = v; altKeyAlts = alts; altKeyUp = lastTypedUpper; altSeq = typedSeq
                            handler.postDelayed(altRunnable, altDelayMs.toLong())
                        }
                    }
                    if (k.repeat) { repeatView = v; repeater.action = k.act; val st = 100L - 10L * repSpeed   // seviye 5 = 50 ms (Gboard)
                        repeater.delay = st; repeater.floor = st            // Gboard gibi sabit hız, ivmelenme yok
                        repeater.nextAt = SystemClock.uptimeMillis() + holdMs + 100L
                        handler.postAtTime(repeater, repeater.nextAt) }  // Gboard: 300 ms uzun basış, 400 ms tekrar başlangıcı
                }
                MotionEvent.ACTION_MOVE -> {
                    if (v === altKeyView) {
                        if (altPopup == null) {
                            // Menü açılmadan parmak kaydıysa / tuştan çıktıysa hiç açma
                            val dx = e.rawX - altDownX; val dy = e.rawY - altDownY
                            val out = e.x < 0 || e.y < 0 || e.x > v.width || e.y > v.height
                            if (out || dx * dx + dy * dy > dp(10) * dp(10)) cancelAltPending()
                        } else updateAltSel(e.rawX, e.rawY)
                    }
                    if (k.repeat && (e.x < 0 || e.y < 0 || e.x > v.width || e.y > v.height)) stopRepeat()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (v === altKeyView) { if (e.actionMasked == MotionEvent.ACTION_UP) finishAlts() else dismissAlts() }
                    if (v === activeKey) { activeKey = null; lastUpT = e.eventTime; lastUpX = e.rawX; lastUpY = e.rawY }
                    v.isPressed = false
                    if (k.repeat) stopRepeat()
                }
            }
            true
        }
    }

    // ---------- Çeviri (Türkçe <-> İngilizce) ----------
    private fun swapLang() {
        fromTr = !fromTr
        chipFrom.text = if (fromTr) "Türkçe" else "İngilizce"
        chipTo.text = if (fromTr) "İngilizce" else "Türkçe"
        if (tOut.isNotBlank()) { tbuf.setLength(0); tbuf.append(tOut) }
        refreshTranslate()
    }

    private fun refreshTranslate() {
        tInput.text = tbuf.toString()
        handler.removeCallbacks(trRunnable)
        if (tbuf.isBlank()) { tOut = ""; tOutput.text = ""; reqId++; return }
        handler.postDelayed(trRunnable, 250)
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 6000; c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
            c.setRequestProperty("Accept", "*/*")
            val code = c.responseCode
            if (code != 200) throw java.io.IOException("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    // Birden çok servis dener; biri çalışmazsa sıradakine geçer
    private fun fetchTranslation(q: String, sl: String, tl: String): String? {
        val enc = URLEncoder.encode(q, "UTF-8")
        val tries = listOf<() -> String>(
            {
                val a = JSONArray(httpGet("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=$enc")).getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until a.length()) sb.append(a.getJSONArray(i).optString(0, ""))
                sb.toString()
            },
            {
                val t = httpGet("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=$sl&tl=$tl&q=$enc").trim()
                if (t.startsWith("{")) {
                    val a = JSONObject(t).getJSONArray("sentences")
                    val sb = StringBuilder()
                    for (i in 0 until a.length()) sb.append(a.getJSONObject(i).optString("trans", ""))
                    sb.toString()
                } else {
                    val j = JSONArray(t)
                    val f = j.get(0)
                    if (f is JSONArray) f.getString(0) else j.getString(0)
                }
            },
            {
                val o = JSONObject(httpGet("https://api.mymemory.translated.net/get?q=$enc&langpair=$sl|$tl"))
                o.getJSONObject("responseData").getString("translatedText")
            }
        )
        for (t in tries) {
            try {
                val r = t()
                if (r.isNotBlank()) return r
            } catch (_: Exception) {}
        }
        return null
    }

    private fun doTranslate() {
        val q = tbuf.toString().take(1500)   // GET isteği çok uzun olursa servisler reddeder
        val id = ++reqId
        val sl = if (fromTr) "tr" else "en"
        val tl = if (fromTr) "en" else "tr"
        safeExec(net) {
            if (id != reqId) return@safeExec // eski istek: boşuna ağa çıkma
            val res = fetchTranslation(q, sl, tl)
            handler.post {
                if (id == reqId) {
                    tOut = res ?: ""
                    tOutput.text = res ?: "Çeviri alınamadı (internet?)"
                }
            }
        }
    }

    // ---------- Ekran görüntüsü önizleme ----------
    private val thumbRunnable: Runnable = Runnable { loadThumbs() }

    // Son kopyalanan METİN: önce panodaki güncel metin, yoksa geçmişin en yenisi
    private fun lastCopiedText(): String? {
        try {
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val d = clip.description
                val sensitive = d.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true
                if (!sensitive && (d.hasMimeType("text/plain") || d.hasMimeType("text/html"))) {
                    val t = clip.getItemAt(0).coerceToText(this)?.toString()
                    if (!t.isNullOrBlank() && t.length <= 20000) return t
                }
            }
        } catch (_: Exception) {}
        return try { store.history().firstOrNull() } catch (_: Exception) { null }
    }

    // Şeridin en başındaki "son kopyalanan metin" önizlemesi; dokununca yazı alanına yapıştırır.
    // v4.2: yeni bir şey kopyalanınca kutunun sol üst köşesinde "Geri al" yazısı belirir; basınca bir öncekini gösterir ("İleri al" ile en yeniye döner)
    private var clipBack = 0
    private var lastClipSeen: String? = null
    private fun addClipCell(txt: String?) {
        if (txt.isNullOrBlank()) return
        if (txt != lastClipSeen) { lastClipSeen = txt; clipBack = 0 }   // yeni kopya geldi: en yeniyi göster
        val list = ArrayList<String>()
        list.add(txt)
        try { for (h in store.history()) if (h != txt && h.isNotBlank()) { list.add(h); break } } catch (_: Exception) {}
        if (clipBack >= list.size) clipBack = 0
        var cur = list[clipBack]
        val hasPrev = list.size > 1
        fun flat(t: String) = t.trim().replace(Regex("\\s+"), " ")
        val tv = TextView(tctx).apply {
            text = flat(cur)
            maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            textSize = 11f; gravity = Gravity.TOP or Gravity.START   // kopyalanan metin kutunun EN ÜSTÜNDEN başlar
            setTextColor(attrColor(R.attr.kbText))
            setPadding(dp(7), if (hasPrev) dp(14) else dp(1), dp(7), dp(1))   // "Geri al" yazısı köşede dururken metin altından başlar
            setBackgroundResource(R.drawable.thumb_bg)
            contentDescription = "Son kopyalanan metin"
            setOnClickListener { commitRaw(cur); if (haptic) buzz() }
            // Basılı tut: Kopyala / Seç / Sabitle menüsü
            setOnLongClickListener {
                if (haptic) buzz(true)
                showClipMenu(this, cur)
                true
            }
        }
        val back = TextView(tctx).apply {
            text = if (clipBack == 0) "Geri al" else "İleri al"
            gravity = Gravity.CENTER; textSize = 9f; setTextColor(attrColor(R.attr.kbText))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(5), dp(1), dp(5), dp(1))
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(0x44808080) }
            contentDescription = "Bir önceki kopyalananı getir"
            visibility = if (hasPrev) View.VISIBLE else View.GONE
            setOnClickListener {
                clipBack = if (clipBack == 0) 1 else 0
                cur = list[clipBack]
                tv.text = flat(cur)
                text = if (clipBack == 0) "Geri al" else "İleri al"
                if (haptic) buzz()
            }
        }
        val frame = FrameLayout(tctx)
        frame.tag = "clip"
        frame.addView(tv, FrameLayout.LayoutParams(-1, -1))
        frame.addView(back, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(3), dp(2), 0, 0) })   // sol üst köşe
        thumbs.addView(frame, LinearLayout.LayoutParams(0, -1, 6.4f).apply { setMargins(0, 0, dp(1), 0) })   // v4.2: daha geniş
    }

    // ---- Gizli mail listesi (Menü tuşuna 6 sn basılı tutunca) ----
    private var menuHeldFired = false
    private val menuHoldRunnable = Runnable { menuHeldFired = true; if (haptic) buzz(true); showMailPanel() }
    private var aboutTaps = 0
    private var aboutLastTap = 0L
    private val aboutLaunch = Runnable { aboutTaps = 0; launchTransparent(AboutActivity::class.java, -1, "Hakkında açılamadı") }
    private var mailPanel: PopupWindow? = null

    private fun dismissMailPanel() { try { mailPanel?.dismiss() } catch (_: Exception) {}; mailPanel = null }

    /** Ekranın sağında, klavyenin hemen üstünde; her satırda adres + yanında Kopyala. Sığmazsa içinde kayar. */
    private fun showMailPanel() {
        try {
            dismissMailPanel()
            if (!::wrapper.isInitialized || !wrapper.isAttachedToWindow) return
            val sw = resources.displayMetrics.widthPixels
            val sh = resources.displayMetrics.heightPixels
            val w = minOf(dp(300), (sw * 0.82f).toInt())
            val maxH = (sh * 0.5f).toInt()
            lateinit var pw: PopupWindow
            // v4.19: panelde sağa/sola kaydırınca yalnızca bu pencere kapanır (klavye açık kalır)
            val card = object : LinearLayout(tctx) {
                private var x0 = 0f; private var y0 = 0f; private var swiping = false
                override fun onInterceptTouchEvent(ev: android.view.MotionEvent): Boolean {
                    when (ev.actionMasked) {
                        android.view.MotionEvent.ACTION_DOWN -> { x0 = ev.rawX; y0 = ev.rawY; swiping = false }
                        android.view.MotionEvent.ACTION_MOVE -> {
                            val dx = ev.rawX - x0; val dy = ev.rawY - y0
                            if (!swiping && kotlin.math.abs(dx) > dp(14) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.5f) swiping = true
                        }
                    }
                    return swiping
                }
                override fun onTouchEvent(ev: android.view.MotionEvent): Boolean {
                    when (ev.actionMasked) {
                        android.view.MotionEvent.ACTION_DOWN -> { x0 = ev.rawX; y0 = ev.rawY; swiping = false }
                        android.view.MotionEvent.ACTION_MOVE -> {
                            val dx = ev.rawX - x0; val dy = ev.rawY - y0
                            if (!swiping && kotlin.math.abs(dx) > dp(14) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.5f) swiping = true
                            if (swiping) translationX = dx
                        }
                        android.view.MotionEvent.ACTION_UP -> {
                            val dx = ev.rawX - x0
                            if (swiping && kotlin.math.abs(dx) > dp(60)) dismissMailPanel() else animate().translationX(0f).setDuration(120).start()
                            swiping = false
                        }
                        android.view.MotionEvent.ACTION_CANCEL -> { translationX = 0f; swiping = false }
                    }
                    return true
                }
            }.apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(4), dp(6), dp(6))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(attrColor(R.attr.kbBg)); cornerRadius = dp(14).toFloat()
                    setStroke(dp(1), attrColor(R.attr.kbSub))
                }
            }
            val head = LinearLayout(tctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(TextView(tctx).apply {
                text = "Mailler (${MailList.all.size})"; textSize = 14f; setTypeface(typeface, Typeface.BOLD)
                setTextColor(attrColor(R.attr.kbSub)); setPadding(dp(8), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(head, LinearLayout.LayoutParams(-1, -2))

            val list = LinearLayout(tctx).apply { orientation = LinearLayout.VERTICAL }
            MailList.all.forEachIndexed { i, mail ->
                val row = LinearLayout(tctx).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(2), dp(4), dp(2))
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(attrColor(R.attr.fnColor)); cornerRadius = dp(10).toFloat()
                    }
                }
                row.addView(TextView(tctx).apply {
                    text = "${i + 1}"; textSize = 12f; setTextColor(attrColor(R.attr.kbSub)); minWidth = dp(20)
                })
                row.addView(TextView(tctx).apply {
                    text = mail; textSize = 14f; setTextColor(attrColor(R.attr.kbText))
                    maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                }, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(ImageView(tctx).apply {
                    setImageResource(R.drawable.ic_copy); setColorFilter(Color.WHITE)
                    contentDescription = "Kopyala"
                    scaleType = ImageView.ScaleType.CENTER
                    background = android.graphics.drawable.GradientDrawable().apply { setColor(0xFF7C5CFF.toInt()); cornerRadius = dp(8).toFloat() }
                    setOnClickListener {
                        try {
                            cm.setPrimaryClip(ClipData.newPlainText("", mail))
                            Toast.makeText(this@ImeService, "Kopyalandı", Toast.LENGTH_SHORT).show()
                            if (haptic) buzz()
                        } catch (_: Exception) {}
                    }
                }, LinearLayout.LayoutParams(dp(40), dp(36)).apply { setMargins(dp(4), 0, 0, 0) })
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(2)) })
            }
            val sv = ScrollView(tctx).apply { isVerticalScrollBarEnabled = true; overScrollMode = View.OVER_SCROLL_NEVER; addView(list) }
            card.addView(sv, LinearLayout.LayoutParams(-1, -2))
            // Kapat tuşu: panelin sağ alt köşesi
            card.addView(TextView(tctx).apply {
                text = "✕"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(attrColor(R.attr.kbText))
                setPadding(dp(18), dp(6), dp(18), dp(6)); setOnClickListener { dismissMailPanel() }
            }, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.END })

            val wSpec = View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY)
            card.measure(wSpec, View.MeasureSpec.UNSPECIFIED)
            if (card.measuredHeight > maxH) {   // sığmıyor: liste kısalır ve kendi içinde kayar, kapat tuşu altta kalır
                sv.layoutParams = LinearLayout.LayoutParams(-1, (sv.measuredHeight - (card.measuredHeight - maxH)).coerceAtLeast(dp(80)))
                card.measure(wSpec, View.MeasureSpec.UNSPECIFIED)
            }
            val h = card.measuredHeight
            pw = PopupWindow(card, w, h).apply {
                isFocusable = false; isOutsideTouchable = false; isClippingEnabled = false
                elevation = dp(10).toFloat()
                inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
            }
            val wl = IntArray(2); wrapper.getLocationOnScreen(wl)
            val wi = IntArray(2); wrapper.getLocationInWindow(wi)
            val x = sw - w - dp(6)
            val y = maxOf(dp(24), wl[1] - h - dp(6))   // klavyenin hemen üstü
            pw.showAtLocation(wrapper, Gravity.NO_GRAVITY, x - (wl[0] - wi[0]), y - (wl[1] - wi[1]))
            mailPanel = pw
        } catch (_: Exception) {}
    }

    // "Son kopyalanan" kutusuna basılı tutunca açılan küçük menü: Kopyala · Seç · Sabitle
    private var clipMenu: PopupWindow? = null
    private fun showClipMenu(anchor: View, txt: String) {
        try {
            clipMenu?.dismiss()
            if (!anchor.isAttachedToWindow || !::wrapper.isInitialized || !wrapper.isAttachedToWindow) return
            lateinit var pw: PopupWindow
            val row = LinearLayout(tctx).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(4), dp(4), dp(4), dp(4))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(attrColor(R.attr.fnColor)); cornerRadius = dp(12).toFloat()
                }
            }
            fun item(label: String, act: () -> Unit) {
                row.addView(TextView(tctx).apply {
                    text = label; textSize = 15f; gravity = Gravity.CENTER
                    setTextColor(attrColor(R.attr.kbText))
                    setPadding(dp(16), dp(10), dp(16), dp(10))
                    setOnClickListener { try { pw.dismiss() } catch (_: Exception) {}; try { act() } catch (_: Exception) {} }
                }, LinearLayout.LayoutParams(-2, -2))
            }
            item("Kopyala") {
                cm.setPrimaryClip(ClipData.newPlainText("", txt))
                Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
            }
            item("Seç") { currentInputConnection?.performContextMenuAction(android.R.id.selectAll) }
            item("Sabitle") {
                store.pin(txt)
                Toast.makeText(this, "Sabitlenenlere eklendi", Toast.LENGTH_SHORT).show()
                if (clipPanel.visibility == View.VISIBLE) reloadClips()
            }
            row.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
            val w = row.measuredWidth; val h = row.measuredHeight
            val loc = IntArray(2); anchor.getLocationOnScreen(loc)
            val sw = resources.displayMetrics.widthPixels
            val x = loc[0].coerceIn(dp(4), maxOf(dp(4), sw - w - dp(4)))
            val y = maxOf(dp(2), loc[1] - h - dp(6))
            val wl = IntArray(2); wrapper.getLocationOnScreen(wl)
            val wi = IntArray(2); wrapper.getLocationInWindow(wi)
            pw = PopupWindow(row, w, h).apply {
                isFocusable = false; isOutsideTouchable = true; isClippingEnabled = false
                elevation = dp(8).toFloat()
                inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
            }
            pw.showAtLocation(wrapper, Gravity.NO_GRAVITY, x - (wl[0] - wi[0]), y - (wl[1] - wi[1]))
            clipMenu = pw
            handler.postDelayed({ try { if (clipMenu === pw) pw.dismiss() } catch (_: Exception) {} }, 4000)   // kendiliğinden kapanır
        } catch (_: Exception) {}
    }

    // ---- Ekran görüntüsü çoklu seçim ----
    private val selShots = LinkedHashSet<String>()
    private val shotBadges = HashMap<String, ShotBadge>()
    private val shotXs = HashMap<String, TextView>()
    private val shotMap = HashMap<String, Shot>()
    private val shotNums = HashMap<String, Int>()
    private var sendSel: TextView? = null

    private fun refreshSel() {
        for ((k, b) in shotBadges) { b.on = selShots.contains(k); b.invalidate() }
        for ((k, x) in shotXs) x.visibility = if (selShots.contains(k)) View.VISIBLE else View.GONE
        sendSel?.visibility = if (selShots.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun toggleShot(key: String) {
        if (!selShots.remove(key)) selShots.add(key)
        refreshSel()
    }

    /** Seçili resimleri numara sırasıyla (1 sonra 2) gönderir. */
    private fun sendSelected() {
        val list = selShots.toList().sortedBy { shotNums[it] ?: 0 }.mapNotNull { shotMap[it] }
        selShots.clear(); refreshSel()
        for ((n, sh) in list.withIndex()) {
            if (n == 0) sendImage(sh)
            else handler.postDelayed({ try { sendImage(sh) } catch (_: Exception) {} }, 1400L * n)
        }
    }

    private fun loadThumbs() {
        if (!::thumbs.isInitialized) return
        val gen = ++thumbGen
        val clipTxt = lastCopiedText()
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            lastThumbKey = ""
            thumbs.removeAllViews()
            addClipCell(clipTxt)
            thumbs.addView(TextView(tctx).apply { text = "Ekran görüntüsü için uygulamadan izin ver"; setTextColor(attrColor(R.attr.kbSub)); textSize = 11f; gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(0, -1, 1.2f).apply { setMargins(dp(3), 0, dp(3), 0) })
            return
        }
        safeExec(bg) {
            val ids = mutableListOf<Pair<Long, String>>()
            try {
                val after = pLong("shotsAfter", 0L)   // sıfırlamadan önceki ekran görüntüleri klavyede gösterilmez
                val sel = "(${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?) AND ${MediaStore.Images.Media.DATE_ADDED} > ?"
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.MIME_TYPE),
                    sel, arrayOf("%creenshot%", "%Ekran%", "%creenshot%", after.toString()),
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    val hidden = prefs().getStringSet("hiddenShots", emptySet()) ?: emptySet()
                    while (c.moveToNext() && ids.size < 2) {   // en son iki ekran görüntüsü yan yana
                        if (hidden.contains(c.getLong(0).toString())) continue   // ✕ ile klavyeden kaldırılanlar
                        ids.add(Pair(c.getLong(0), c.getString(1) ?: "image/png"))
                    }
                }
            } catch (_: Exception) {}
            val key = ids.joinToString(",") { it.first.toString() } + "|" + (clipTxt?.hashCode() ?: 0)
            if (key == lastThumbKey || gen != thumbGen) return@safeExec
            if (thumbCache.size > 24) thumbCache.clear()   // bellek şişmesin
            val out = ids.map { (id, mime) ->
                val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                val bmp = thumbCache[uri.toString()] ?: try {
                    contentResolver.loadThumbnail(uri, Size(160, 160), null).also { thumbCache[uri.toString()] = it }
                } catch (e: Exception) { null }
                Shot(uri, mime, bmp)
            }
            handler.post {
                if (gen != thumbGen) return@post   // daha yeni bir yükleme başladı
                lastThumbKey = key
                thumbs.removeAllViews()
                addClipCell(clipTxt)
                selShots.clear(); shotBadges.clear(); shotXs.clear(); shotMap.clear(); shotNums.clear()
                for ((idx, sh) in out.withIndex()) {
                    val num = 2 - idx            // en son çekilen = 2, bir öncekisi = 1
                    val key = sh.uri.toString()
                    shotMap[key] = sh; shotNums[key] = num
                    val iv = ImageView(tctx).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        setBackgroundResource(R.drawable.thumb_bg)
                        outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
                        sh.bmp?.let { setImageBitmap(it) }
                        // Seçim açıkken dokunmak seç/vazgeç yapar; seçim yokken tek dokunuş tek resmi gönderir
                        setOnClickListener {
                            if (selShots.isNotEmpty()) { toggleShot(key); return@setOnClickListener }
                            // v4.18: hızlı çift dokunuş = ekran görüntüsü albümü (çoklu seçim); tek dokunuş kısa bir bekleyişle tek resmi gönderir
                            val now = SystemClock.uptimeMillis()
                            if (shotTapPending != null && now - shotTapAt <= 320) {
                                handler.removeCallbacks(shotTapPending!!); shotTapPending = null
                                openShotAlbum(sh)
                            } else {
                                shotTapAt = now
                                val r = Runnable { shotTapPending = null; sendImage(sh) }
                                shotTapPending = r
                                handler.postDelayed(r, 330)
                            }
                        }
                        // Basılı tutunca seçer (numara kırmızı olur); diğerine de basılı tutarak ya da dokunarak ikisi birden seçilir
                        setOnLongClickListener {
                            if (!selShots.contains(key)) toggleShot(key)
                            if (haptic) buzz(true)
                            true
                        }
                    }
                    val badge = ShotBadge(tctx, num)
                    // Seçiliyken sol üstte ✕: bu görüntüyü klavyeden kaldırır
                    val xBtn = TextView(tctx).apply {
                        text = "✕"; gravity = Gravity.CENTER; textSize = 12f; setTextColor(0xFFFFFFFF.toInt())
                        setTypeface(typeface, Typeface.BOLD)
                        background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(0xFFE53935.toInt()) }
                        visibility = View.GONE
                        setOnClickListener {
                            val id = sh.uri.lastPathSegment ?: return@setOnClickListener
                            val set = HashSet(prefs().getStringSet("hiddenShots", emptySet()) ?: emptySet())
                            set.add(id)
                            prefs().edit().putStringSet("hiddenShots", set).apply()
                            lastThumbKey = "removed"; thumbCache.remove(key)
                            loadThumbs()
                        }
                    }
                    shotBadges[key] = badge; shotXs[key] = xBtn
                    val cell = FrameLayout(tctx)
                    cell.addView(iv, FrameLayout.LayoutParams(-1, -1))
                    cell.addView(badge, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(3), dp(3)) })   // sağ alt köşe
                    cell.addView(xBtn, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.START).apply { setMargins(dp(2), dp(2), 0, 0) })
                    thumbs.addView(cell, LinearLayout.LayoutParams(0, -1, 1.2f).apply { setMargins(dp(1), 0, 0, 0) })
                }
                // Seçili resimleri gönder düğmesi (yalnızca seçim varken görünür)
                val send = TextView(tctx).apply {
                    text = "➤"; gravity = Gravity.CENTER; textSize = 18f; setTextColor(0xFF39FF14.toInt())
                    background = android.graphics.drawable.GradientDrawable().apply {
                        shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(0xCC000000.toInt()); setStroke(dp(2), 0xFF39FF14.toInt())
                    }
                    visibility = View.GONE
                    setOnClickListener { sendSelected() }
                }
                sendSel = send
                thumbs.addView(send, LinearLayout.LayoutParams(0, dp(40), 0.5f).apply { setMargins(dp(4), 0, dp(2), 0); gravity = Gravity.CENTER_VERTICAL })
            }
        }
    }

    // Seçilen dosyayı hedef uygulamaya verir. Sıra: (1) alan içerik kabul ediyorsa doğrudan,
    // (2) olmazsa (tarayıcı, web alanları, çoğu uygulama) panoya koy + yapıştırmayı dene, (3) yine olmazsa panoda kalır.
    private fun sendImage(s: Shot) {
        val ic = currentInputConnection
        val ei = currentInputEditorInfo
        if (ic != null && ei != null) {
            try {
                val ok = EditorInfoCompat.getContentMimeTypes(ei).any { ClipDescription.compareMimeTypes(s.mime, it) }
                if (ok) {
                    val info = InputContentInfoCompat(s.uri, ClipDescription("file", arrayOf(s.mime)), null)
                    if (InputConnectionCompat.commitContent(ic, ei, info, InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)) return
                }
            } catch (_: Exception) {}
        }
        try {
            cm.setPrimaryClip(ClipData.newUri(contentResolver, "file", s.uri))
            if (ic != null) {
                handler.postDelayed({
                    val pasted = try { currentInputConnection?.let { pasteIntoField(it) } == true } catch (_: Exception) { false }
                    Toast.makeText(this, if (pasted) "Yapıştırıldı" else "Panoya kopyalandı; alana basılı tutup Yapıştır'ı seç", Toast.LENGTH_LONG).show()
                }, 150)
            } else Toast.makeText(this, "Panoya kopyalandı; yazı alanına basılı tutup Yapıştır'ı seç", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Dosya bu uygulamaya aktarılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Ataç: fotoğraf / video / belge seç, mikrofon: sesle yaz ----------
    private var shotTapAt = 0L
    private var shotTapPending: Runnable? = null

    /** Ekran görüntüsünün klasörünü (Pictures/Screenshots, DCIM/Screenshots vb.) bulup seçiciyi orada açar; birden fazla resim seçilebilir. */
    private fun openShotAlbum(sh: Shot) {
        var rel: String? = null
        try {
            contentResolver.query(sh.uri, arrayOf(MediaStore.Images.Media.RELATIVE_PATH), null, null, null)?.use { c ->
                if (c.moveToFirst()) rel = c.getString(0)
            }
        } catch (_: Exception) {}
        val initial = rel?.trim('/')?.takeIf { it.isNotEmpty() }?.let { "content://com.android.externalstorage.documents/document/primary%3A" + Uri.encode(it) }
        showCats(false)
        launchTransparent(PickerActivity::class.java, 0, "Albüm açılamadı", initial)
    }

    private fun launchTransparent(cls: Class<*>, kind: Int = -1, err: String, initial: String? = null) {
        try {
            val i = Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            if (kind >= 0) i.putExtra(PickerActivity.EXTRA_KIND, kind)
            if (initial != null) i.putExtra(PickerActivity.EXTRA_INITIAL, initial)
            startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(this, err, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openPicker(kind: Int) {
        showCats(false)
        returnToCatsAt = SystemClock.elapsedRealtime()
        launchTransparent(PickerActivity::class.java, kind, "Dosya seçici açılamadı")
    }

    private fun openVoice() = launchTransparent(VoiceActivity::class.java, -1, "Sesle yazma açılamadı")

    // Seçici/ses ekranı kapanıp hedef uygulama tekrar bağlanana kadar bekler; bağlantı gecikirse kısa aralıklarla yeniden dener
    private val deliverRunnable: Runnable = object : Runnable {
        override fun run() {
            if (pending == null && pendingText == null) return
            if (SystemClock.elapsedRealtime() - pendingAt > PENDING_TTL_MS) { pending = null; pendingText = null; return }
            val ic = currentInputConnection
            if (ic == null || currentInputEditorInfo == null) {
                if (++deliverTries <= 20) handler.postDelayed(this, 200)   // en çok ~4 sn
                return                                                     // sonra: sonraki bağlanmada denenir
            }
            deliverTries = 0
            try {
                val t = pendingText
                if (t != null) { pendingText = null; ic.commitText(t, 1) }
                val p = pending
                if (p != null) {
                    pending = null; sendImage(Shot(p.first, p.second, null))
                    // v4.1: birden fazla dosya seçildiyse kalanlar sırayla (aralıklı) gönderilir
                    val extra = pendingExtra; pendingExtra = emptyList()
                    for ((n, q) in extra.withIndex()) handler.postDelayed({ try { sendImage(Shot(q.first, q.second, null)) } catch (_: Exception) {} }, 1400L * (n + 1))
                }
            } catch (_: Exception) { pending = null; pendingText = null }
        }
    }

    private fun deliverPending() {
        if (pending == null && pendingText == null) return
        deliverTries = 0
        handler.removeCallbacks(deliverRunnable)
        handler.postDelayed(deliverRunnable, 200)
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        deliverPending()
    }

    // ---------- Paneller: 0 tuşlar, 1 pano, 2 tuş boyutu, 3 çeviri ----------
    private fun showPanel(which: Int) {
        try { showPanelInner(which) } catch (_: Exception) {   // bir panel hatası klavyeyi kapatmasın: tuşlara dön
            try { sizePanel.visibility = View.GONE; clipPanel.visibility = View.GONE; translatePanel.visibility = View.GONE; editPanel.visibility = View.GONE
                if (::emojiPanel.isInitialized) emojiPanel.visibility = View.GONE
                topStrip.visibility = View.VISIBLE; keys.visibility = View.VISIBLE } catch (_: Exception) {}
        }
    }

    // Ayar paneli ekranın en fazla ~%55'i kadar; taşarsa kendi içinde kayar
    private fun capPx(): Int {
        val h = resources.displayMetrics.heightPixels
        return if (isLand()) h - dp(16) else (h * 0.55f).toInt()
    }

    private fun showPanelInner(which: Int) {
        if (!::clipPanel.isInitialized) return
        stopRepeat()
        if (which != 1 && which != 4) clipView = 0
        if (::clipDlg.isInitialized) clipDlg.visibility = View.GONE
        translating = which == 3
        editing = which == 4
        if (which == 1 || which == 3 || which == 4) setTools(true, false)
        hl(btnTr, translating)
        hl(btnCl, which == 1 || which == 4)
        clipPanel.visibility = if (which == 1) View.VISIBLE else View.GONE
        if (::emojiPanel.isInitialized) emojiPanel.visibility = if (which == 5) View.VISIBLE else View.GONE
        sizePanel.visibility = if (which == 2) View.VISIBLE else View.GONE
        translatePanel.visibility = if (translating) View.VISIBLE else View.GONE
        editPanel.visibility = if (editing) View.VISIBLE else View.GONE
        (sizePanel as? CapScrollView)?.let { if (which == 2) { it.maxPx = capPx(); it.scrollTo(0, 0) } }
        topStrip.visibility = if (which in 1..5) View.GONE else View.VISIBLE   // bir sayfadayken menü şeridi görünmez
        keys.visibility = if (which == 1 || which == 5) View.INVISIBLE else if (which == 2 && isLand()) View.GONE else View.VISIBLE
        if (!translating && !editing) {
            tbuf.setLength(0); tOut = ""; reqId++
            handler.removeCallbacks(trRunnable)
            tInput.text = ""; tOutput.text = ""
            tEdit.text = ""
            if (::tTitle.isInitialized) { tTitle.text = ""; tTitle.visibility = View.GONE }
            editOnTitle = false; otherBuf = ""; otherCur = 0
        }
        val chk = translating || editing
        if (chk != enterChk) { enterChk = chk; for (v in enterViews) setEnterIcon(v) }
        if (which == 1) reloadClips()
        if (which == 5) showEmojiCat(if (recentEmojis().isNotEmpty()) 0 else if (pinnedEmojis().isNotEmpty()) 1 else 2)
        if (which == 2 && ::driveInfo.isInitialized) driveInfo.text = BackupActivity.describe(this)
    }

    private fun editInsert(t: String) {
        tbuf.insert(editCur, t); editCur += t.length
        renderEdit()
    }

    // Aktif alandaki metni imleçle birlikte göster (uzun metinde imlecin çevresini); diğer alan düz görünür
    private fun renderEdit() {
        val n = tbuf.length
        val st = maxOf(0, editCur - 90)
        val en = minOf(n, editCur + 90)
        val pre = if (st > 0) "…" else ""
        val post = if (en < n) "…" else ""
        editStart = st; editPre = pre.length
        val b = SpannableStringBuilder()
        b.append(pre).append(tbuf.substring(st, editCur))
        val pos = b.length
        b.append("│").append(tbuf.substring(editCur, en)).append(post)
        b.setSpan(ForegroundColorSpan(attrColor(R.attr.accentText)), pos, pos + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (editOnTitle) { tTitle.text = b; tEdit.text = otherBuf }
        else {
            tEdit.text = b
            if (tTitle.visibility == View.VISIBLE) tTitle.text = otherBuf
        }
    }

    // Başlık <-> metin alanı arasında geç (sadece sabitlenenlerde başlık alanı var)
    private fun switchEditField(toTitle: Boolean) {
        if (!editing || editItem?.pinned != true || toTitle == editOnTitle) return
        val b = tbuf.toString(); val c = editCur
        tbuf.setLength(0); tbuf.append(otherBuf)
        editCur = otherCur.coerceIn(0, tbuf.length)
        otherBuf = b; otherCur = c
        editOnTitle = toTitle
        renderEdit()
    }

    private fun editTap(tv: TextView, x: Float, y: Float) {
        val lay = tv.layout ?: return
        val px = x - tv.totalPaddingLeft + tv.scrollX
        val py = (y - tv.totalPaddingTop + tv.scrollY).toInt().coerceAtLeast(0)
        val line = lay.getLineForVertical(py)
        var off = lay.getOffsetForHorizontal(line, px)
        val dispCur = editPre + (editCur - editStart)
        if (off > dispCur) off -= 1
        editCur = (off - editPre + editStart).coerceIn(0, tbuf.length)
        renderEdit()
    }

    private fun startEdit(item: ClipItem) {
        editItem = item
        showPanel(4)
        tbuf.setLength(0); tbuf.append(item.text)
        editCur = tbuf.length
        editOnTitle = false
        otherBuf = if (item.pinned) item.title else ""
        otherCur = otherBuf.length
        tTitle.visibility = if (item.pinned) View.VISIBLE else View.GONE
        renderEdit()
    }

    private fun saveEdit() {
        val it = editItem
        val cur = tbuf.toString()
        val text: String; val title: String
        if (it?.pinned == true) {
            if (editOnTitle) { text = otherBuf; title = cur } else { text = cur; title = otherBuf }
        } else { text = cur; title = "" }
        if (it != null && text.isNotBlank()) {
            if (text != it.text) store.replace(it.text, text, it.pinned)
            if (it.pinned) store.setTitle(text, title)
        }
        editItem = null
        showPanel(1)
    }

    // ---------- Emoji paneli: kategoriler + son kullanılanlar; Google (Noto) emoji seti ----------
    private lateinit var emojiPanel: View
    private lateinit var emojiRv: RecyclerView
    private var emojiCur = 1
    private var emojiGroups: List<Pair<String, List<String>>>? = null
    private val emojiTabs = ArrayList<TextView>()
    private var emojiShown: MutableList<String> = mutableListOf()
    private var emoMoved = false

    private fun loadEmojiGroups(): List<Pair<String, List<String>>> {
        emojiGroups?.let { return it }
        val res = ArrayList<Pair<String, List<String>>>()
        try {
            val p = Paint()
            var name = ""
            assets.open("emoji.txt").bufferedReader().useLines { lines ->
                for (ln in lines) {
                    if (ln.startsWith("#")) { name = ln.substring(1) }
                    else if (ln.isNotBlank()) {
                        // Telefonun gösteremediği (yeni) emojiler çıkarılır: kutu / boşluk görünmesin
                        res.add(name to ln.trim().split(" ").filter { p.hasGlyph(it) })
                    }
                }
            }
        } catch (_: Exception) {}
        emojiGroups = res
        return res
    }

    private fun recentEmojis(): List<String> =
        prefs().getString("emoji_recent", "")!!.split(" ").filter { it.isNotEmpty() }
    private fun pinnedEmojis(): MutableList<String> =
        prefs().getString("emoji_pinned", "")!!.split(" ").filter { it.isNotEmpty() }.toMutableList()
    private fun savePinnedEmojis(l: List<String>) { prefs().edit().putString("emoji_pinned", l.joinToString(" ")).apply() }
    private fun addRecentEmoji(e: String) {
        val l = recentEmojis().toMutableList(); l.remove(e); l.add(0, e)
        prefs().edit().putString("emoji_recent", l.take(32).joinToString(" ")).apply()
    }

    private fun setupEmojiPanel(root: View) {
        emojiPanel = root.findViewById(R.id.emojiPanel)
        emojiRv = root.findViewById(R.id.emojiList)
        emojiRv.layoutManager = GridLayoutManager(tctx, 8)
        emojiRv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = emojiShown.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val tv = TextView(tctx).apply {
                    gravity = Gravity.CENTER; textSize = 26f
                    layoutParams = RecyclerView.LayoutParams(-1, dp(46))
                }
                return object : RecyclerView.ViewHolder(tv) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                val e = emojiShown[i]
                (h.itemView as TextView).text = e
                h.itemView.setOnClickListener { typeText(e); addRecentEmoji(e); if (haptic) buzz() }
                // Basılı tut: Sabitlenen kategorisine ekle (Sabitlenen kategorisinin içinde basılı tutma = sürükle / kaldır)
                if (emojiCur == 1) { h.itemView.setOnLongClickListener(null); h.itemView.isLongClickable = false }
                else h.itemView.setOnLongClickListener {
                    val p = pinnedEmojis()
                    if (p.contains(e)) Toast.makeText(this@ImeService, "Zaten Sabitlenen'de", Toast.LENGTH_SHORT).show()
                    else { p.add(e); savePinnedEmojis(p); Toast.makeText(this@ImeService, "$e Sabitlenen'e eklendi", Toast.LENGTH_SHORT).show() }
                    if (haptic) buzz(); true
                }
            }
        }
        // Sabitlenen emoji kategorisinde: basılı tutup sürükle = yer değiştir; sürüklemeden bırak = kaldırma sorusu
        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.START or ItemTouchHelper.END, 0) {
            override fun isLongPressDragEnabled() = emojiCur == 1
            override fun onMove(r: RecyclerView, v: RecyclerView.ViewHolder, t: RecyclerView.ViewHolder): Boolean {
                if (emojiCur != 1) return false
                val a = v.bindingAdapterPosition; val b = t.bindingAdapterPosition
                if (a < 0 || b < 0 || a >= emojiShown.size || b >= emojiShown.size) return false
                emojiShown.add(b, emojiShown.removeAt(a)); emojiRv.adapter?.notifyItemMoved(a, b); emoMoved = true; return true
            }
            override fun onSelectedChanged(v: RecyclerView.ViewHolder?, st: Int) {
                super.onSelectedChanged(v, st)
                if (st == ItemTouchHelper.ACTION_STATE_DRAG) emoMoved = false
            }
            override fun onSwiped(v: RecyclerView.ViewHolder, d: Int) {}
            override fun clearView(r: RecyclerView, v: RecyclerView.ViewHolder) {
                super.clearView(r, v)
                if (emojiCur != 1) return
                if (emoMoved) { savePinnedEmojis(emojiShown); emoMoved = false }
                else {
                    val pos = v.bindingAdapterPosition
                    val e = emojiShown.getOrNull(pos) ?: return
                    showDlg("$e Sabitlenen'den kaldırılsın mı?", "Kaldır" to {
                        val p = pinnedEmojis(); p.remove(e); savePinnedEmojis(p); showEmojiCat(1)
                    }, "Vazgeç" to {})
                }
            }
        }).attachToRecyclerView(emojiRv)
        root.findViewById<View>(R.id.emoBack).setOnClickListener { showPanel(0) }
        root.findViewById<View>(R.id.emoDel).setOnClickListener { back() }
        val cats = root.findViewById<LinearLayout>(R.id.emoCats)
        val icons = listOf("🕒", "📌", "😀", "👋", "🐻", "🍔", "⚽", "🚗", "💡", "🔣", "🏁")
        emojiTabs.clear()
        for ((i, ic) in icons.withIndex()) {
            val tv = TextView(tctx).apply {
                text = ic; textSize = 20f; gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(10), 0)
                setOnClickListener { showEmojiCat(i) }
            }
            emojiTabs.add(tv)
            cats.addView(tv, LinearLayout.LayoutParams(-2, -1))
        }
    }

    private fun showEmojiCat(i: Int) {
        emojiCur = i
        val g = loadEmojiGroups()
        emojiShown = (if (i == 0) recentEmojis() else if (i == 1) pinnedEmojis() else g.getOrNull(i - 2)?.second ?: emptyList()).toMutableList()
        emojiRv.adapter?.notifyDataSetChanged()
        emojiRv.scrollToPosition(0)
        for ((k, t) in emojiTabs.withIndex()) t.setBackgroundResource(if (k == i) R.drawable.key_bg else 0)
    }

    // ---------- Pano: onay penceresi, çöp kutuları ----------
    private fun showDlg(msg: String, vararg btns: Pair<String, () -> Unit>) {
        if (!::clipDlg.isInitialized) return
        dlgMsg.text = msg
        for ((k, v) in dlgBtns.withIndex()) {
            val b = btns.getOrNull(k)
            if (b == null) { v.visibility = View.GONE; continue }
            v.text = b.first; v.visibility = View.VISIBLE
            v.setOnClickListener { clipDlg.visibility = View.GONE; try { b.second() } catch (_: Exception) {} }
        }
        clipDlg.visibility = View.VISIBLE
    }

    private fun confirmDelete(item: ClipItem) {
        if (item.trash) {
            showDlg("Kalıcı olarak silinsin mi?\nBu işlem geri alınamaz.",
                "Evet, sil" to { store.purgeTrash(clipView == 1, item.num - 1); reloadClips() },
                "Vazgeç" to {})
        } else {
            showDlg("Emin misiniz?\nSilinen not çöp kutusuna gider, oradan geri alabilirsiniz.",
                "Evet, sil" to { store.delete(item.text, item.pinned); reloadClips() },
                "Vazgeç" to {})
        }
    }

    private fun onClipHeader(item: ClipItem, which: Int) {
        when (item.hdr) {
            1 -> if (which == 0) { clipView = 1; reloadClips() }                      // sabit çöp kutusunu aç
            2 -> if (which == 0) { clipView = 2; reloadClips() }                      // geçmiş çöp kutusunu aç
                 else showDlg("Geçmiş boşaltılsın mı?\nGeçmiş silinip geçmiş çöp kutusuna gidecek. Oradan geri alabilirsiniz.",
                    "Evet, boşalt" to { store.clearHistory(); reloadClips() }, "Vazgeç" to {})
            3, 4 -> if (which == 0) { clipView = 0; reloadClips() }
                 else showDlg("Çöp kutusu boşaltılsın mı?\nİçindekiler kalıcı olarak silinir, geri alınamaz.",
                    "Evet, boşalt" to { store.emptyTrash(clipView == 1); reloadClips() }, "Vazgeç" to {})
        }
    }

    private fun reloadClips() {
        val list = mutableListOf<ClipItem>()
        if (clipView != 0) {
            val pt = clipView == 1
            val tr = if (pt) store.pinnedTrash() else store.historyTrash()
            list.add(ClipItem(if (pt) "Sabit çöp kutusu" else "Geçmiş çöp kutusu", false, true, hdr = if (pt) 3 else 4, countA = tr.size))
            tr.forEachIndexed { i, x -> list.add(ClipItem(x.text, false, false, x.title, num = i + 1, time = x.at, trash = true)) }
            adapter.submit(list)
            return
        }
        // En son kopyalanan en üstte, onun altında sabitlenenler, sonra diğer geçmiş (son 30, 1'den başlayıp artan numara)
        val times = store.times()
        val hist = store.history().mapIndexed { i, t -> ClipItem(t, false, num = i + 1, time = times[t] ?: 0L) }
        val pins = store.pinned()
        val titles = store.titles()
        list.add(ClipItem("Sabitlenenler", true, true, hdr = 1, countA = store.pinnedTrash().size))
        pins.forEachIndexed { i, t -> list.add(ClipItem(t, true, false, titles[t] ?: "", color = store.colorFor(t, ClipAdapter.PALETTE.size), num = i + 1)) }
        if (hist.isNotEmpty()) { list.add(0, hist[0]); list.add(0, ClipItem("En son", false, true)) }
        list.add(ClipItem("Geçmiş (son 30)", false, true, hdr = 2, countA = store.historyTrash().size))
        list.addAll(hist.drop(1))
        adapter.submit(list)
        updateUndo()
    }

    private fun updateUndo() {
        if (!::btnUndo.isInitialized) return
        btnUndo.visibility = View.GONE
        clipHint.visibility = View.VISIBLE
        clipPanel.findViewById<View>(R.id.undoSpacer).visibility = View.GONE
    }
}
