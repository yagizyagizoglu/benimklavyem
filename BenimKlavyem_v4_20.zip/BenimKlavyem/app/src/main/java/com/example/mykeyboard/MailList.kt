package com.example.mykeyboard

/** Gizli mail listesi (Menü tuşunu 6 sn basılı tutunca açılır). Listeyi buradan düzenle. */
object MailList {
    // Ekran görüntüsünde adresler "@g", "@o", "@ic" diye kısaydı; tam alan adları burada eşleniyor.
    private val domains = mapOf(
        "g" to "gmail.com",
        "o" to "outlook.com",
        "ic" to "icloud.com"
    )

    private val raw = listOf(
        "dyagizoglu@g", "dyagizoglu.redmi13pro@g", "dyagizoglu.redmi13prois@g",
        "dsmartdukkan@g", "dsmartdukkan1@g",
        "dyagizoglu.secret@g", "dyagizoglu.secret1@g", "dyagizoglusecret2@g",
        "dyagizoglu.secret3@g", "dyagizoglu.secret4@g",
        "dyagizoglusecret5@g", "dyagizoglusecret6@g", "dyagizoglusecret7@g",
        "dyagizoglusecret8@g", "dyagizoglusecret9@g",
        "dyagizoglu.secret10@g", "dyagizoglu.secret11@g",
        "dyagizoglu.bsra@g", "dyagizoglu.annem@g",
        "sexsdoctor@g", "antonvictor006@g", "parcapimcik@g", "kankaboydan@g",
        "tablettesthesabi35@g", "sertacccandansu@g", "perfectlover8891@g",
        "cancanimsin576@g", "yagiz.yagizoglu@o",
        "duyguyagizoglu@ic", "duygu.yagizoglu@ic", "sertaccandan918@g"
    )

    val all: List<String> = raw.map { m ->
        val i = m.lastIndexOf('@')
        val dom = m.substring(i + 1)
        m.substring(0, i + 1) + (domains[dom] ?: dom)
    }
}
