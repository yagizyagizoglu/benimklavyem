package com.example.mykeyboard

import android.content.Context
import android.view.View
import android.view.ViewGroup

/** Alt alta satırlara sarılan basit yerleşim (kelime kutucukları için). */
class FlowLayout(ctx: Context, private val hGap: Int, private val vGap: Int) : ViewGroup(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        val maxW = MeasureSpec.getSize(w) - paddingLeft - paddingRight
        var x = 0; var y = 0; var lineH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i); if (c.visibility == View.GONE) continue
            c.measure(MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
            val cw = c.measuredWidth; val ch = c.measuredHeight
            if (x > 0 && x + cw > maxW) { x = 0; y += lineH + vGap; lineH = 0 }
            x += cw + hGap; if (ch > lineH) lineH = ch
        }
        setMeasuredDimension(MeasureSpec.getSize(w), y + lineH + paddingTop + paddingBottom)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = r - l - paddingLeft - paddingRight
        var x = 0; var y = 0; var lineH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i); if (c.visibility == View.GONE) continue
            val cw = c.measuredWidth; val ch = c.measuredHeight
            if (x > 0 && x + cw > maxW) { x = 0; y += lineH + vGap; lineH = 0 }
            c.layout(paddingLeft + x, paddingTop + y, paddingLeft + x + cw, paddingTop + y + ch)
            x += cw + hGap; if (ch > lineH) lineH = ch
        }
    }
}
